# Stripe Setup Guide (No Webhooks)

This guide will help you set up Stripe payments for your booking system without webhooks.

## Step 1: Create a Stripe Account

1. Go to [https://stripe.com](https://stripe.com) and create an account
2. Complete the account verification process

## Step 2: Get Your API Keys

1. Log into your Stripe Dashboard
2. Go to **Developers** → **API keys**
3. Copy your **Publishable key** (starts with `pk_test_` for testing)
4. Copy your **Secret key** (starts with `sk_test_` for testing)

## Step 3: Configure Environment Variables

Create a `.env` file in your project root with the following content:

```env
# Stripe Configuration
STRIPE_PUBLISHABLE_KEY=pk_test_your_publishable_key_here
STRIPE_SECRET_KEY=sk_test_your_secret_key_here
```

Replace `pk_test_your_publishable_key_here` and `sk_test_your_secret_key_here` with your actual Stripe keys.

## Step 4: Test the Booking System

1. Start your Flask application: `python app.py`
2. Go to a service booking page (e.g., `/booking/service/fingerprinting`)
3. Fill out the booking form
4. Click "Complete Booking & Pay"
5. You should be redirected to Stripe's checkout page

## Step 5: Test Payments

For testing, you can use these test card numbers:
- **Success**: `4242 4242 4242 4242`
- **Decline**: `4000 0000 0000 0002`
- **Expiry**: Any future date
- **CVC**: Any 3 digits

## Troubleshooting

### "Payment processing is not configured" Error
- Check that your `.env` file exists and contains the correct Stripe keys
- Restart your Flask application after adding the `.env` file
- Verify the keys are correct in your Stripe dashboard

### "Stripe publishable key is not configured" Error
- Make sure your `STRIPE_PUBLISHABLE_KEY` is set in the `.env` file
- Check that the key starts with `pk_test_` or `pk_live_`

### Booking not completing after payment
- Check your browser's developer console for JavaScript errors
- Verify that the success URL is correctly configured in your Stripe checkout session

## Production Setup

When ready for production:

1. Switch to **Live** mode in your Stripe dashboard
2. Update your `.env` file with live keys (starting with `pk_live_` and `sk_live_`)
3. Test thoroughly with small amounts before going live

## Security Notes

- Never commit your `.env` file to version control
- Keep your secret key secure and never expose it in client-side code
- Use HTTPS in production for secure payment processing 