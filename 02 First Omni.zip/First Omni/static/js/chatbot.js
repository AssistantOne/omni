// OmniQuest Services Chatbot
class OmniQuestChatbot {
    constructor() {
        console.log('Chatbot constructor called');
        this.isOpen = false;
        this.sessionId = null;
        this.messages = [];
        this.initialMessage = null;
        this.init();
    }

    init() {
        console.log('Chatbot init called');
        this.createWidget();
        this.bindEvents();
        this.startChat();
    }

    createWidget() {
        console.log('Creating chatbot widget');
        
        // Add CSS animations
        const style = document.createElement('style');
        style.textContent = `
            @keyframes fadeInUp {
                from {
                    opacity: 0;
                    transform: translateY(10px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            @keyframes typingDot {
                0%, 60%, 100% {
                    transform: translateY(0);
                    opacity: 0.4;
                }
                30% {
                    transform: translateY(-8px);
                    opacity: 1;
                }
            }
            
            @keyframes pulse {
                0% {
                    transform: scale(1);
                }
                50% {
                    transform: scale(1.05);
                }
                100% {
                    transform: scale(1);
                }
            }
            
            #chat-button:hover {
                transform: scale(1.1) !important;
                box-shadow: 0 8px 25px rgba(1, 88, 119, 0.5) !important;
            }
            
            #chat-input:focus {
                border-color: #015877 !important;
                background: white !important;
                box-shadow: 0 0 0 3px rgba(1, 88, 119, 0.1) !important;
            }
            
            #send-message:hover {
                transform: scale(1.1) !important;
                box-shadow: 0 6px 15px rgba(1, 88, 119, 0.4) !important;
            }
            
            #close-chat:hover {
                background: rgba(255,255,255,0.3) !important;
                transform: scale(1.1) !important;
            }
        `;
        document.head.appendChild(style);
        
        const widgetHTML = `
            <div id="omniquest-chatbot" style="position: fixed; bottom: 20px; right: 20px; z-index: 9999; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
                <!-- Chat Button -->
                <div id="chat-button" style="width: 60px; height: 60px; background: linear-gradient(135deg, #015877, #00d4aa); border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: 0 6px 20px rgba(1, 88, 119, 0.4); transition: all 0.3s ease; border: 3px solid white; position: relative;">
                    <i class="fas fa-comments" style="color: white; font-size: 24px; text-shadow: 0 2px 4px rgba(0,0,0,0.2);"></i>
                    <div style="position: absolute; top: -5px; right: -5px; width: 18px; height: 18px; background: #ff4757; border-radius: 50%; border: 2px solid white; display: flex; align-items: center; justify-content: center; animation: pulse 2s infinite;">
                        <span style="color: white; font-size: 9px; font-weight: bold;">1</span>
                    </div>
                </div>
                
                <!-- Chat Window -->
                <div id="chat-window" style="display: none; width: 320px; height: 450px; background: white; border-radius: 15px; box-shadow: 0 15px 35px rgba(0,0,0,0.2); position: absolute; bottom: 0; right: 80px; overflow: hidden; border: 1px solid #e1e8ed;">
                    <!-- Header -->
                    <div style="background: linear-gradient(135deg, #015877, #00d4aa); color: white; padding: 18px 20px; display: flex; justify-content: space-between; align-items: center; position: relative; min-height: 70px;">
                        <div style="display: flex; align-items: center; gap: 12px; flex: 1; min-width: 0; margin-right: 15px;">
                            <div style="width: 32px; height: 32px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                                <i class="fas fa-headset" style="font-size: 14px;"></i>
                            </div>
                            <div style="min-width: 0; flex: 1;">
                                <h4 style="margin: 0 0 4px 0; font-size: 15px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">OmniQuest Services</h4>
                                <small style="opacity: 0.9; font-size: 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">Online Assistant</small>
                            </div>
                        </div>
                        <button id="close-chat" style="background: rgba(255,255,255,0.2); border: none; color: white; cursor: pointer; font-size: 20px; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; flex-shrink: 0;">×</button>
                    </div>
                    
                    <!-- Messages Container -->
                    <div id="chat-messages" style="height: 320px; overflow-y: auto; padding: 15px; background: #f8f9fa; scroll-behavior: smooth;">
                        <!-- Messages will be added here -->
                    </div>
                    
                    <!-- Input Area -->
                    <div style="padding: 15px; border-top: 1px solid #e9ecef; background: white;">
                        <div style="display: flex; gap: 10px; align-items: center;">
                            <input type="text" id="chat-input" placeholder="Type your message here..." style="flex: 1; padding: 10px 14px; border: 2px solid #e1e8ed; border-radius: 20px; outline: none; font-size: 13px; transition: all 0.3s ease; background: #f8f9fa;">
                            <button id="send-message" style="background: linear-gradient(135deg, #015877, #00d4aa); color: white; border: none; padding: 10px 14px; border-radius: 50%; cursor: pointer; width: 38px; height: 38px; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; box-shadow: 0 4px 12px rgba(1, 88, 119, 0.3);">
                                <i class="fas fa-paper-plane" style="font-size: 12px;"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', widgetHTML);
        console.log('Chatbot widget created');
        
        // Verify the widget is created
        setTimeout(() => {
            const chatButton = document.getElementById('chat-button');
            if (chatButton) {
                console.log('✅ Chatbot button found and visible');
            } else {
                console.error('❌ Chatbot button not found');
            }
        }, 1000);
    }

    bindEvents() {
        console.log('Binding chatbot events');
        // Chat button toggle
        document.getElementById('chat-button').addEventListener('click', () => {
            console.log('Chat button clicked');
            this.toggleChat();
        });

        // Close button
        document.getElementById('close-chat').addEventListener('click', () => {
            console.log('Close button clicked');
            this.toggleChat();
        });

        // Send message
        document.getElementById('send-message').addEventListener('click', () => {
            console.log('Send button clicked');
            this.sendMessage();
        });

        // Enter key to send
        document.getElementById('chat-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                console.log('Enter key pressed');
                this.sendMessage();
            }
        });
        console.log('Chatbot events bound');
    }

    toggleChat() {
        console.log('Toggling chat, current state:', this.isOpen);
        const chatWindow = document.getElementById('chat-window');
        const chatButton = document.getElementById('chat-button');
        
        if (this.isOpen) {
            chatWindow.style.display = 'none';
            chatButton.style.transform = 'scale(1)';
        } else {
            chatWindow.style.display = 'block';
            chatButton.style.transform = 'scale(1.1)';
            document.getElementById('chat-input').focus();
            
            // Show initial message if this is the first time opening
            if (this.initialMessage && this.messages.length === 0) {
                this.addMessage(this.initialMessage, 'bot');
                console.log('📝 Showing initial message');
            }
        }
        
        this.isOpen = !this.isOpen;
        console.log('Chat toggled, new state:', this.isOpen);
    }

    async startChat() {
        console.log('Starting chat...');
        try {
            const response = await fetch('/chat/api/start', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({})
            });
            
            console.log('Start chat response:', response);
            const data = await response.json();
            console.log('Start chat data:', data);
            
            if (data.session_id) {
                this.sessionId = data.session_id;
                // Store the initial message but don't display it yet
                this.initialMessage = data.message;
                console.log('✅ Chat session started with ID:', data.session_id);
            } else {
                // Fallback message if no session_id
                this.initialMessage = 'Hello! Welcome to OmniQuest Services. How can I help you today?';
                console.log('⚠️ No session ID, using fallback message');
            }
        } catch (error) {
            console.error('Error starting chat:', error);
            // Show fallback message even if API fails
            this.initialMessage = 'Hello! Welcome to OmniQuest Services. How can I help you today?';
            console.log('⚠️ API error, using fallback message');
        }
    }

    async sendMessage() {
        const input = document.getElementById('chat-input');
        const message = input.value.trim();
        
        if (!message) return;
        
        console.log('Sending message:', message);
        
        // Add user message
        this.addMessage(message, 'user');
        input.value = '';
        
        // Show typing indicator
        this.showTyping();
        
        try {
            console.log('Making API call to /chat/api/message');
            const response = await fetch('/chat/api/message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: message,
                    session_id: this.sessionId
                })
            });
            
            console.log('Message API response status:', response.status);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            console.log('Message API response data:', data);
            
            // Hide typing indicator
            this.hideTyping();
            
            if (data.message) {
                this.addMessage(data.message, 'bot');
                console.log('✅ Bot response added');
            } else {
                console.warn('⚠️ No message in API response');
                this.addMessage('I apologize, but I\'m having trouble processing your request. Please try again or contact us directly at (404) 474-3125.', 'bot');
            }
            
            // Add suggested actions if any
            if (data.suggested_actions && data.suggested_actions.length > 0) {
                this.addSuggestedActions(data.suggested_actions);
                console.log('✅ Suggested actions added');
            }
            
        } catch (error) {
            console.error('Error sending message:', error);
            this.hideTyping();
            this.addMessage('Sorry, I\'m having trouble right now. Please call us at (404) 474-3125 for immediate assistance.', 'bot');
        }
    }

    addMessage(content, sender) {
        const messagesContainer = document.getElementById('chat-messages');
        const messageDiv = document.createElement('div');
        
        const isBot = sender === 'bot';
        const alignment = isBot ? 'flex-start' : 'flex-end';
        const bgColor = isBot ? '#ffffff' : 'linear-gradient(135deg, #015877, #00d4aa)';
        const textColor = isBot ? '#2c3e50' : 'white';
        const borderColor = isBot ? '#e1e8ed' : 'transparent';
        
        messageDiv.style.cssText = `
            margin: 8px 0;
            display: flex;
            justify-content: ${alignment};
            animation: fadeInUp 0.3s ease-out;
        `;
        
        const messageBubble = document.createElement('div');
        messageBubble.style.cssText = `
            max-width: 80%;
            padding: 10px 14px;
            border-radius: ${isBot ? '15px 15px 15px 3px' : '15px 15px 3px 15px'};
            background: ${bgColor};
            color: ${textColor};
            word-wrap: break-word;
            line-height: 1.4;
            font-size: 13px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            border: 1px solid ${borderColor};
            position: relative;
            ${isBot ? `
                margin-right: auto;
                margin-left: 0;
            ` : `
                margin-left: auto;
                margin-right: 0;
            `}
        `;
        
        // Add avatar for bot messages
        if (isBot) {
            const avatar = document.createElement('div');
            avatar.style.cssText = `
                width: 24px;
                height: 24px;
                background: linear-gradient(135deg, #015877, #00d4aa);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-right: 6px;
                flex-shrink: 0;
            `;
            avatar.innerHTML = '<i class="fas fa-headset" style="color: white; font-size: 10px;"></i>';
            
            const messageWrapper = document.createElement('div');
            messageWrapper.style.cssText = `
                display: flex;
                align-items: flex-start;
                gap: 6px;
                width: 100%;
            `;
            
            messageWrapper.appendChild(avatar);
            messageWrapper.appendChild(messageBubble);
            messageDiv.appendChild(messageWrapper);
        } else {
            messageDiv.appendChild(messageBubble);
        }
        
        // Convert line breaks to <br> tags and handle emojis
        messageBubble.innerHTML = content.replace(/\n/g, '<br>');
        
        messagesContainer.appendChild(messageDiv);
        
        // Track the message
        this.messages.push({ content, sender, timestamp: new Date() });
        console.log(`📝 Message added: ${sender} - ${content.substring(0, 50)}...`);
        
        // Scroll to bottom with smooth animation
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        // Add hover effect
        messageBubble.addEventListener('mouseenter', () => {
            messageBubble.style.transform = 'translateY(-1px)';
            messageBubble.style.boxShadow = '0 3px 8px rgba(0,0,0,0.15)';
        });
        
        messageBubble.addEventListener('mouseleave', () => {
            messageBubble.style.transform = 'translateY(0)';
            messageBubble.style.boxShadow = '0 2px 6px rgba(0,0,0,0.1)';
        });
    }

    showTyping() {
        const messagesContainer = document.getElementById('chat-messages');
        const typingDiv = document.createElement('div');
        typingDiv.id = 'typing-indicator';
        typingDiv.style.cssText = `
            margin: 8px 0;
            display: flex;
            justify-content: flex-start;
            animation: fadeInUp 0.3s ease-out;
        `;
        
        const avatar = document.createElement('div');
        avatar.style.cssText = `
            width: 24px;
            height: 24px;
            background: linear-gradient(135deg, #015877, #00d4aa);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 6px;
            flex-shrink: 0;
        `;
        avatar.innerHTML = '<i class="fas fa-headset" style="color: white; font-size: 10px;"></i>';
        
        const typingBubble = document.createElement('div');
        typingBubble.style.cssText = `
            padding: 10px 14px;
            border-radius: 15px 15px 15px 3px;
            background: #ffffff;
            color: #2c3e50;
            border: 1px solid #e1e8ed;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 3px;
        `;
        
        // Create typing dots animation
        for (let i = 0; i < 3; i++) {
            const dot = document.createElement('div');
            dot.style.cssText = `
                width: 5px;
                height: 5px;
                background: #015877;
                border-radius: 50%;
                animation: typingDot 1.4s infinite ease-in-out;
                animation-delay: ${i * 0.2}s;
            `;
            typingBubble.appendChild(dot);
        }
        
        const wrapper = document.createElement('div');
        wrapper.style.cssText = `
            display: flex;
            align-items: flex-start;
            gap: 6px;
            width: 100%;
        `;
        
        wrapper.appendChild(avatar);
        wrapper.appendChild(typingBubble);
        typingDiv.appendChild(wrapper);
        messagesContainer.appendChild(typingDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    hideTyping() {
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }

    addSuggestedActions(actions) {
        const messagesContainer = document.getElementById('chat-messages');
        const actionsDiv = document.createElement('div');
        actionsDiv.style.cssText = `
            margin: 8px 0;
            display: flex;
            flex-direction: column;
            gap: 6px;
            animation: fadeInUp 0.3s ease-out;
        `;
        
        actions.forEach(action => {
            const actionButton = document.createElement('button');
            actionButton.style.cssText = `
                background: linear-gradient(135deg, #015877, #00d4aa);
                color: white;
                border: none;
                padding: 10px 12px;
                border-radius: 10px;
                cursor: pointer;
                font-size: 12px;
                text-align: left;
                transition: all 0.3s ease;
                box-shadow: 0 2px 6px rgba(1, 88, 119, 0.2);
                font-weight: 500;
                display: flex;
                align-items: center;
                gap: 6px;
                max-width: 240px;
            `;
            
            // Add icon based on action type
            let icon = 'fas fa-arrow-right';
            if (action.text.includes('Book') || action.text.includes('Appointment')) {
                icon = 'fas fa-calendar-alt';
            } else if (action.text.includes('Quote') || action.text.includes('Price')) {
                icon = 'fas fa-dollar-sign';
            }
            
            actionButton.innerHTML = `<i class="${icon}" style="font-size: 10px;"></i>${action.text}`;
            
            actionButton.addEventListener('click', () => {
                if (action.url) {
                    window.open(action.url, '_blank');
                }
            });
            
            actionButton.addEventListener('mouseenter', () => {
                actionButton.style.transform = 'translateY(-1px)';
                actionButton.style.boxShadow = '0 3px 8px rgba(1, 88, 119, 0.3)';
            });
            
            actionButton.addEventListener('mouseleave', () => {
                actionButton.style.transform = 'translateY(0)';
                actionButton.style.boxShadow = '0 2px 6px rgba(1, 88, 119, 0.2)';
            });
            
            actionsDiv.appendChild(actionButton);
        });
        
        messagesContainer.appendChild(actionsDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
}

// Initialize chatbot when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing chatbot...');
    try {
        new OmniQuestChatbot();
        console.log('Chatbot initialized successfully');
    } catch (error) {
        console.error('Error initializing chatbot:', error);
    }
});