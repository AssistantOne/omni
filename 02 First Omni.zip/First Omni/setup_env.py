#!/usr/bin/env python3
"""
Setup script for OmniQuest Services environment configuration
This script helps you create a proper .env file with your actual values
"""

import os
import secrets
import string

def generate_secret_key(length=32):
    """Generate a secure secret key"""
    alphabet = string.ascii_letters + string.digits + string.punctuation
    return ''.join(secrets.choice(alphabet) for _ in range(length))

def setup_env():
    """Interactive setup for .env file"""
    print("🚀 OmniQuest Services Environment Setup")
    print("=" * 50)
    
    # Check if .env already exists
    if os.path.exists('.env'):
        response = input("⚠️  .env file already exists. Overwrite? (y/N): ")
        if response.lower() != 'y':
            print("Setup cancelled.")
            return
    
    # Collect configuration values
    config = {}
    
    print("\n📝 Please provide the following information:")
    print("(Press Enter to use default values where available)\n")
    
    # Flask Configuration
    config['SECRET_KEY'] = input("Secret Key (leave empty to generate): ").strip() or generate_secret_key()
    config['FLASK_ENV'] = input("Flask Environment (development/production) [development]: ").strip() or 'development'
    config['DEBUG'] = input("Debug Mode (True/False) [True]: ").strip() or 'True'
    
    # Database Configuration
    config['DATABASE_URL'] = input("Database URL [sqlite:///omniquest.db]: ").strip() or 'sqlite:///omniquest.db'
    
    # Email Configuration
    print("\n📧 Email Configuration:")
    config['MAIL_USERNAME'] = input("Gmail Username: ").strip()
    config['MAIL_PASSWORD'] = input("Gmail App Password: ").strip()
    config['MAIL_DEFAULT_SENDER'] = input("Default Sender Email: ").strip() or config['MAIL_USERNAME']
    
    # Stripe Configuration
    print("\n💳 Stripe Configuration:")
    config['STRIPE_PUBLISHABLE_KEY'] = input("Stripe Publishable Key (pk_test_...): ").strip()
    config['STRIPE_SECRET_KEY'] = input("Stripe Secret Key (sk_test_...): ").strip()
    
    # OpenAI Configuration
    print("\n🤖 OpenAI Configuration:")
    config['OPENAI_API_KEY'] = input("OpenAI API Key: ").strip()
    
    # Application Settings
    print("\n🌐 Application Settings:")
    config['APP_NAME'] = input("App Name [OmniQuest Services]: ").strip() or 'OmniQuest Services'
    config['APP_URL'] = input("App URL [http://localhost:5000]: ").strip() or 'http://localhost:5000'
    
    # Admin Settings
    print("\n👤 Admin Settings:")
    config['ADMIN_EMAIL'] = input("Admin Email [admin@omniquestservices.com]: ").strip() or 'admin@omniquestservices.com'
    config['ADMIN_USERNAME'] = input("Admin Username [admin]: ").strip() or 'admin'
    config['ADMIN_PASSWORD'] = input("Admin Password: ").strip()
    
    # Create .env file
    env_content = f"""# Flask Configuration
SECRET_KEY={config['SECRET_KEY']}
FLASK_ENV={config['FLASK_ENV']}
DEBUG={config['DEBUG']}

# Database Configuration
DATABASE_URL={config['DATABASE_URL']}

# Email Configuration (Gmail SMTP)
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME={config['MAIL_USERNAME']}
MAIL_PASSWORD={config['MAIL_PASSWORD']}
MAIL_DEFAULT_SENDER={config['MAIL_DEFAULT_SENDER']}

# Stripe Configuration
STRIPE_PUBLISHABLE_KEY={config['STRIPE_PUBLISHABLE_KEY']}
STRIPE_SECRET_KEY={config['STRIPE_SECRET_KEY']}

# OpenAI Configuration
OPENAI_API_KEY={config['OPENAI_API_KEY']}

# Application Settings
APP_NAME={config['APP_NAME']}
APP_URL={config['APP_URL']}

# Redis Configuration (for Celery)
REDIS_URL=redis://localhost:6379/0

# Security Settings
WTF_CSRF_ENABLED=True
WTF_CSRF_TIME_LIMIT=3600

# File Upload Settings
MAX_CONTENT_LENGTH=16777216  # 16MB max file size
UPLOAD_FOLDER=static/uploads

# Admin Settings
ADMIN_EMAIL={config['ADMIN_EMAIL']}
ADMIN_USERNAME={config['ADMIN_USERNAME']}
ADMIN_PASSWORD={config['ADMIN_PASSWORD']}
"""
    
    # Write .env file
    with open('.env', 'w') as f:
        f.write(env_content)
    
    print("\n✅ .env file created successfully!")
    print("\n📋 Next steps:")
    print("1. Review the .env file and update any values if needed")
    print("2. Run: python setup_admin.py")
    print("3. Run: python app.py")
    print("\n🔒 Security Note: Keep your .env file secure and never commit it to version control!")

if __name__ == '__main__':
    setup_env() 