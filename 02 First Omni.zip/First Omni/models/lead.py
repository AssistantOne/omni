from datetime import datetime
from database import db
import json

class Lead(db.Model):
    __tablename__ = 'leads'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    service_type = db.Column(db.String(50), nullable=False)
    form_data = db.Column(db.Text, nullable=False)  # JSON string
    status = db.Column(db.String(20), nullable=False, default='new')  # new, contacted, converted, closed
    priority = db.Column(db.String(10), nullable=False, default='medium')  # low, medium, high
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<Lead {self.id} - {self.service_type} - {self.status}>'
    
    def get_form_data(self):
        """Parse JSON form data"""
        try:
            return json.loads(self.form_data)
        except json.JSONDecodeError:
            return {}
    
    def set_form_data(self, data):
        """Set form data as JSON string"""
        self.form_data = json.dumps(data)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'service_type': self.service_type,
            'form_data': self.get_form_data(),
            'status': self.status,
            'priority': self.priority,
            'notes': self.notes,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'user': self.user.to_dict() if self.user else None
        }