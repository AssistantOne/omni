from datetime import datetime
from database import db
from sqlalchemy import Numeric

class Appointment(db.Model):
    __tablename__ = 'appointments'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    service_type = db.Column(db.String(50), nullable=False)
    appointment_date = db.Column(db.DateTime, nullable=False)
    appointment_time = db.Column(db.String(10), nullable=False)  # e.g., "10:00 AM"
    duration_minutes = db.Column(db.Integer, nullable=False, default=60)
    location_type = db.Column(db.String(20), nullable=False, default='office')  # office, mobile, virtual
    address = db.Column(db.Text, nullable=True)  # For mobile services
    payment_status = db.Column(db.String(20), nullable=False, default='pending')  # pending, paid, failed, refunded
    payment_amount = db.Column(Numeric(10, 2), nullable=True)
    stripe_payment_intent_id = db.Column(db.String(100), nullable=True)
    status = db.Column(db.String(20), nullable=False, default='scheduled')  # scheduled, confirmed, completed, cancelled, no_show
    reminders_sent = db.Column(db.Integer, nullable=False, default=0)
    email_sent = db.Column(db.Boolean, nullable=False, default=False)  # Track if confirmation email was sent
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<Appointment {self.id} - {self.service_type} - {self.appointment_date}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'service_type': self.service_type,
            'appointment_date': self.appointment_date.isoformat(),
            'appointment_time': self.appointment_time,
            'duration_minutes': self.duration_minutes,
            'location_type': self.location_type,
            'address': self.address,
            'payment_status': self.payment_status,
            'payment_amount': float(self.payment_amount) if self.payment_amount else None,
            'stripe_payment_intent_id': self.stripe_payment_intent_id,
            'status': self.status,
            'reminders_sent': self.reminders_sent,
            'email_sent': self.email_sent,
            'notes': self.notes,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'user': self.user.to_dict() if self.user else None
        }