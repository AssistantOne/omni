# OmniQuest Services - Deployment Guide

This comprehensive guide will help you deploy the OmniQuest Services web application on a VPS.

## 📋 Prerequisites

- Ubuntu 20.04+ VPS with root access
- Domain name (optional but recommended)
- Basic knowledge of Linux commands

## 🚀 Quick Start (Development)

1. **Clone and Setup**
```bash
# Copy all files to your project directory
cd /path/to/your/project

# Install Python dependencies
pip install -r requirements.txt

# Copy environment configuration
cp config.env.example .env

# Edit the .env file with your settings
nano .env
```

2. **Setup Database and Admin**
```bash
# Create admin user and setup database
python setup_admin.py

# Run the application
python app.py
```

3. **Access the Application**
- Website: http://localhost:5000
- Admin Panel: http://localhost:5000/admin/login

## 🌐 Production Deployment

### Step 1: Server Setup

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install python3 python3-pip nginx supervisor postgresql postgresql-contrib redis-server -y

# Install Python package manager
sudo apt install python3-venv -y
```

### Step 2: Create Application User

```bash
# Create application user
sudo adduser omniquest
sudo usermod -aG sudo omniquest

# Switch to application user
sudo su - omniquest
```

### Step 3: Setup Application

```bash
# Create application directory
mkdir /home/omniquest/app
cd /home/omniquest/app

# Copy your application files here
# (Upload all files from your development environment)

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
pip install gunicorn psycopg2-binary
```

### Step 4: Configure Database

```bash
# Switch to postgres user
sudo su - postgres

# Create database and user
createdb omniquest_db
createuser omniquest_user
psql -c "ALTER USER omniquest_user WITH PASSWORD 'your_secure_password';"
psql -c "GRANT ALL PRIVILEGES ON DATABASE omniquest_db TO omniquest_user;"
exit
```

### Step 5: Environment Configuration

```bash
# Create production environment file
cd /home/omniquest/app
cp config.env.example .env

# Edit environment variables
nano .env
```

**Important .env variables for production:**
```bash
SECRET_KEY=your-very-secure-secret-key-here
FLASK_ENV=production
DEBUG=False
DATABASE_URL=postgresql://omniquest_user:your_secure_password@localhost/omniquest_db

# Email settings (Gmail example)
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password

# Stripe settings
STRIPE_PUBLISHABLE_KEY=pk_live_your_publishable_key
STRIPE_SECRET_KEY=sk_live_your_secret_key
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret

# OpenAI API
OPENAI_API_KEY=your-openai-api-key

# Application settings
APP_URL=https://yourdomain.com
ADMIN_EMAIL=admin@omniquestservices.com
```

### Step 6: Initialize Database

```bash
# Setup admin user and database
python setup_admin.py
```

### Step 7: Configure Gunicorn

Create `/home/omniquest/app/gunicorn.conf.py`:
```python
bind = "127.0.0.1:8000"
workers = 3
worker_class = "sync"
worker_connections = 1000
max_requests = 1000
max_requests_jitter = 100
timeout = 30
keepalive = 5
user = "omniquest"
group = "omniquest"
tmp_upload_dir = None
errorlog = "/home/omniquest/app/logs/gunicorn_error.log"
accesslog = "/home/omniquest/app/logs/gunicorn_access.log"
loglevel = "info"
```

Create log directory:
```bash
mkdir /home/omniquest/app/logs
```

### Step 8: Configure Supervisor

Create `/etc/supervisor/conf.d/omniquest.conf`:
```ini
[program:omniquest]
command=/home/omniquest/app/venv/bin/gunicorn -c gunicorn.conf.py app:app
directory=/home/omniquest/app
user=omniquest
autostart=true
autorestart=true
redirect_stderr=true
stdout_logfile=/home/omniquest/app/logs/app.log
```

Start supervisor:
```bash
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start omniquest
```

### Step 9: Configure Nginx

Create `/etc/nginx/sites-available/omniquest`:
```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    
    client_max_body_size 20M;
    
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_connect_timeout 300s;
        proxy_read_timeout 300s;
    }
    
    location /static/ {
        alias /home/omniquest/app/static/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Security headers
    add_header X-Content-Type-Options nosniff;
    add_header X-Frame-Options DENY;
    add_header X-XSS-Protection "1; mode=block";
}
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/omniquest /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### Step 10: Setup SSL with Let's Encrypt

```bash
# Install Certbot
sudo apt install snapd
sudo snap install core; sudo snap refresh core
sudo snap install --classic certbot

# Create symlink
sudo ln -s /snap/bin/certbot /usr/bin/certbot

# Get SSL certificate
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Test auto-renewal
sudo certbot renew --dry-run
```

### Step 11: Configure Firewall

```bash
# Enable UFW firewall
sudo ufw enable

# Allow SSH, HTTP, and HTTPS
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'

# Check status
sudo ufw status
```

## 🔧 Configuration Details

### Email Setup (Gmail)

1. Enable 2-factor authentication on your Gmail account
2. Generate an App Password:
   - Go to Google Account settings
   - Security → 2-Step Verification → App passwords
   - Generate password for "Mail"
3. Use the generated password in `MAIL_PASSWORD`

### Stripe Setup

1. Create a Stripe account at https://stripe.com
2. Get your API keys from the Dashboard
3. Set up webhooks for payment confirmations
4. Add webhook endpoint: `https://yourdomain.com/booking/api/webhook/stripe`

### OpenAI Setup

1. Create an OpenAI account
2. Generate an API key
3. Add credits to your account for chatbot functionality

## 📊 Monitoring & Maintenance

### Log Files

- Application logs: `/home/omniquest/app/logs/app.log`
- Nginx access: `/var/log/nginx/access.log`
- Nginx error: `/var/log/nginx/error.log`

### Useful Commands

```bash
# Check application status
sudo supervisorctl status omniquest

# Restart application
sudo supervisorctl restart omniquest

# View logs
tail -f /home/omniquest/app/logs/app.log

# Restart Nginx
sudo systemctl restart nginx

# Check database
sudo su - postgres
psql omniquest_db
```

### Database Backup

```bash
# Create backup script
sudo nano /home/omniquest/backup.sh

#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
pg_dump omniquest_db > /home/omniquest/backups/backup_$DATE.sql

# Make executable
sudo chmod +x /home/omniquest/backup.sh

# Add to crontab for daily backups
crontab -e
0 2 * * * /home/omniquest/backup.sh
```

## 🔒 Security Checklist

- [ ] Change default admin password
- [ ] Use strong SECRET_KEY
- [ ] Enable SSL/HTTPS
- [ ] Configure firewall
- [ ] Regular security updates
- [ ] Monitor access logs
- [ ] Backup database regularly
- [ ] Use environment variables for secrets

## 🆘 Troubleshooting

### Common Issues

1. **Application won't start**
   - Check logs: `tail -f /home/omniquest/app/logs/app.log`
   - Verify environment variables
   - Check database connection

2. **502 Bad Gateway**
   - Check if Gunicorn is running: `sudo supervisorctl status`
   - Verify Nginx configuration: `sudo nginx -t`

3. **Database connection errors**
   - Verify PostgreSQL is running: `sudo systemctl status postgresql`
   - Check database credentials in .env

4. **Email not sending**
   - Verify SMTP settings
   - Check Gmail app password
   - Review firewall settings

## 📞 Support

For additional support:
- Check application logs first
- Review this guide
- Contact: admin@omniquestservices.com

## 🚀 Performance Optimization

### For High Traffic

1. **Increase Gunicorn workers**
```python
# In gunicorn.conf.py
workers = (2 * cpu_cores) + 1
```

2. **Enable Redis caching**
```bash
# Install Redis
sudo apt install redis-server

# Configure in .env
REDIS_URL=redis://localhost:6379/0
```

3. **Database optimization**
```sql
-- Create indexes for better performance
CREATE INDEX idx_leads_created_at ON leads(created_at);
CREATE INDEX idx_appointments_date ON appointments(appointment_date);
```

Your OmniQuest Services application is now ready for production! 🎉