from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for, current_app
from models.appointment import Appointment
from models.user import User
from database import db
from datetime import datetime, timedelta
from utils.email_service import send_appointment_confirmation
import stripe
import json

def send_booking_confirmation_email(appointment):
    """Send booking confirmation email"""
    try:
        # Check if email was already sent to prevent duplicates
        if hasattr(appointment, 'email_sent') and appointment.email_sent:
            current_app.logger.info(f'Email already sent for appointment {appointment.id}, skipping')
            return True
        
        # Send the confirmation email using the email service
        success = send_appointment_confirmation(appointment)
        if success:
            # Mark that email was sent
            appointment.email_sent = True
            db.session.commit()
            current_app.logger.info(f'Booking confirmation email sent for appointment {appointment.id}')
        else:
            current_app.logger.error(f'Failed to send confirmation email for appointment {appointment.id}')
        return success
    except Exception as e:
        current_app.logger.error(f'Error sending confirmation email: {str(e)}')
        return False

booking_bp = Blueprint('booking', __name__)

@booking_bp.route('/')
def booking_calendar():
    """Main booking page with calendar"""
    return render_template('booking/calendar.html')



@booking_bp.route('/service/<service_type>')
def book_service(service_type):
    """Service-specific booking page"""
    # Service pricing configuration
    service_prices = {
        'fingerprinting': {'price': 50.00, 'duration': 30},
        'notary': {'price': 15.00, 'duration': 30},
        'immigration': {'price': 150.00, 'duration': 90},
        'tax': {'price': 100.00, 'duration': 60},
        'itin': {'price': 75.00, 'duration': 45},
        'insurance': {'price': 0.00, 'duration': 45}  # Free consultation
    }
    
    if service_type not in service_prices:
        flash('Invalid service type.', 'error')
        return redirect(url_for('main.index'))
    
    service_info = service_prices[service_type]
    return render_template('booking/service_booking.html', 
                         service_type=service_type, 
                         service_info=service_info)

@booking_bp.route('/api/available-slots')
def available_slots():
    """API endpoint to get available time slots"""
    try:
        date_str = request.args.get('date')
        service_type = request.args.get('service_type', 'general')
        
        if not date_str:
            return jsonify({'error': 'Date parameter required'}), 400
        
        # Parse date
        appointment_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        
        # Check if date is in the past
        if appointment_date < datetime.now().date():
            return jsonify({'slots': []})
        
        # Business hours configuration
        business_hours = {
            'monday': {'start': '10:00', 'end': '18:00'},
            'tuesday': {'start': '10:00', 'end': '18:00'},
            'wednesday': {'start': '10:00', 'end': '18:00'},
            'thursday': {'start': '10:00', 'end': '18:00'},
            'friday': {'start': '10:00', 'end': '18:00'},
            'saturday': {'start': '10:00', 'end': '14:00'},
            'sunday': None  # Closed
        }
        
        # Get day of week (0=Monday, 6=Sunday)
        day_name = appointment_date.strftime('%A').lower()
        
        # Check if business is open
        if not business_hours.get(day_name):
            return jsonify({'slots': []})
        
        hours = business_hours[day_name]
        
        # Generate time slots (30-minute intervals)
        slots = []
        start_time = datetime.strptime(hours['start'], '%H:%M').time()
        end_time = datetime.strptime(hours['end'], '%H:%M').time()
        
        current_time = datetime.combine(appointment_date, start_time)
        end_datetime = datetime.combine(appointment_date, end_time)
        
        while current_time < end_datetime:
            # Check if slot is already booked
            existing_appointment = Appointment.query.filter_by(
                appointment_date=appointment_date,
                appointment_time=current_time.strftime('%I:%M %p'),
                status='scheduled'
            ).first()
            
            if not existing_appointment:
                slots.append({
                    'time': current_time.strftime('%I:%M %p'),
                    'value': current_time.strftime('%H:%M'),
                    'available': True
                })
            
            current_time += timedelta(minutes=30)
        
        return jsonify({'slots': slots})
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@booking_bp.route('/api/create-payment-intent', methods=['POST'])
def create_payment_intent():
    """Create Stripe payment intent"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['service_type', 'amount', 'name', 'email', 'phone', 'date', 'time']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Configure Stripe
        stripe_secret_key = current_app.config['STRIPE_SECRET_KEY']
        if not stripe_secret_key:
            return jsonify({'error': 'Payment processing is not configured. Please contact support.'}), 500
        
        stripe.api_key = stripe_secret_key
        
        # Create or get user
        user = User.query.filter_by(email=data['email']).first()
        if not user:
            user = User(
                name=data['name'],
                email=data['email'],
                phone=data['phone'],
                service_requested=data['service_type']
            )
            db.session.add(user)
            db.session.flush()
        
        # Create appointment record
        appointment_date = datetime.strptime(data['date'], '%Y-%m-%d').date()
        appointment = Appointment(
            user_id=user.id,
            service_type=data['service_type'],
            appointment_date=appointment_date,
            appointment_time=data['time'],
            location_type=data.get('location_type', 'office'),
            address=data.get('address'),
            payment_amount=data['amount'],
            payment_status='pending',
            status='scheduled'
        )
        db.session.add(appointment)
        db.session.flush()
        
        # Create Stripe payment intent
        intent = stripe.PaymentIntent.create(
            amount=int(float(data['amount']) * 100),  # Convert to cents
            currency='usd',
            metadata={
                'appointment_id': appointment.id,
                'service_type': data['service_type'],
                'user_email': data['email']
            }
        )
        
        # Update appointment with payment intent ID
        appointment.stripe_payment_intent_id = intent.id
        db.session.commit()
        
        return jsonify({
            'client_secret': intent.client_secret,
            'appointment_id': appointment.id
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@booking_bp.route('/api/create-checkout-session', methods=['POST'])
def create_checkout_session():
    """Create Stripe Checkout session"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['service_type', 'amount', 'name', 'email', 'phone', 'date', 'time']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Configure Stripe
        stripe_secret_key = current_app.config['STRIPE_SECRET_KEY']
        if not stripe_secret_key:
            return jsonify({'error': 'Payment processing is not configured. Please contact support.'}), 500
        
        stripe.api_key = stripe_secret_key
        
        # Create or get user
        user = User.query.filter_by(email=data['email']).first()
        if not user:
            user = User(
                name=data['name'],
                email=data['email'],
                phone=data['phone'],
                service_requested=data['service_type']
            )
            db.session.add(user)
            db.session.flush()
        
        # Create appointment record
        appointment_date = datetime.strptime(data['date'], '%Y-%m-%d').date()
        appointment = Appointment(
            user_id=user.id,
            service_type=data['service_type'],
            appointment_date=appointment_date,
            appointment_time=data['time'],
            location_type=data.get('location_type', 'office'),
            address=data.get('address'),
            payment_amount=data['amount'],
            payment_status='pending',  # Set to pending initially
            status='scheduled'         # Set to scheduled initially
        )
        db.session.add(appointment)
        db.session.flush()
        
        # Create Stripe Checkout session
        session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': f'{data["service_type"].title()} Service',
                        'description': f'Appointment on {data["date"]} at {data["time"]}',
                    },
                    'unit_amount': int(float(data['amount']) * 100),  # Convert to cents
                },
                'quantity': 1,
            }],
            mode='payment',
            success_url=request.host_url + f'booking/confirmation/{appointment.id}?payment=success',
            cancel_url=request.host_url + 'booking/cancel',
            metadata={
                'appointment_id': appointment.id,
                'service_type': data['service_type'],
                'user_email': data['email']
            },
            customer_email=data['email']
        )
        
        # Update appointment with session ID
        appointment.stripe_payment_intent_id = session.id
        db.session.commit()
        
        return jsonify({
            'url': session.url,
            'appointment_id': appointment.id
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@booking_bp.route('/api/confirm-booking', methods=['POST'])
def confirm_booking():
    """Confirm booking after payment"""
    try:
        data = request.get_json()
        appointment_id = data.get('appointment_id')
        
        if not appointment_id:
            return jsonify({'error': 'Missing appointment_id'}), 400
        
        appointment = Appointment.query.get(appointment_id)
        if not appointment:
            return jsonify({'error': 'Appointment not found'}), 404
        
        # For Stripe Checkout, payment is already confirmed
        appointment.payment_status = 'paid'
        appointment.status = 'confirmed'
        db.session.commit()
        
        # Send confirmation email
        send_booking_confirmation_email(appointment)
        
        return jsonify({'message': 'Booking confirmed successfully'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@booking_bp.route('/confirmation/<int:appointment_id>')
def booking_confirmation(appointment_id):
    """Show booking confirmation page"""
    appointment = Appointment.query.get_or_404(appointment_id)
    
    # Check if user is coming from Stripe Checkout (success)
    # If they have a Stripe session ID and payment is still pending, update it
    payment_success = request.args.get('payment') == 'success'
    if (appointment.stripe_payment_intent_id and appointment.payment_status == 'pending') or payment_success:
        try:
            # Configure Stripe
            stripe_secret_key = current_app.config['STRIPE_SECRET_KEY']
            if stripe_secret_key:
                stripe.api_key = stripe_secret_key
                
                # Check if this is a checkout session
                if appointment.stripe_payment_intent_id.startswith('cs_'):
                    # It's a checkout session, check if it's completed
                    session = stripe.checkout.Session.retrieve(appointment.stripe_payment_intent_id)
                    if session.payment_status == 'paid' and appointment.payment_status != 'paid':
                        appointment.payment_status = 'paid'
                        appointment.status = 'confirmed'
                        db.session.commit()
                        current_app.logger.info(f'Payment confirmed for appointment {appointment_id}')
                        
                        # Send confirmation email
                        send_booking_confirmation_email(appointment)
                
                # Check if this is a payment intent
                elif appointment.stripe_payment_intent_id.startswith('pi_'):
                    # It's a payment intent, check if it's succeeded
                    intent = stripe.PaymentIntent.retrieve(appointment.stripe_payment_intent_id)
                    if intent.status == 'succeeded' and appointment.payment_status != 'paid':
                        appointment.payment_status = 'paid'
                        appointment.status = 'confirmed'
                        db.session.commit()
                        current_app.logger.info(f'Payment confirmed for appointment {appointment_id}')
                        
                        # Send confirmation email
                        send_booking_confirmation_email(appointment)
                        
        except Exception as e:
            current_app.logger.error(f'Error checking payment status: {str(e)}')
    
    return render_template('booking/confirmation.html', appointment=appointment)

@booking_bp.route('/cancel')
def booking_cancel():
    """Show booking cancellation page"""
    return render_template('booking/cancel.html')

@booking_bp.route('/api/update-payment-status/<int:appointment_id>', methods=['POST'])
def update_payment_status(appointment_id):
    """Manually update payment status for testing"""
    try:
        data = request.get_json()
        new_status = data.get('status', 'paid')
        
        appointment = Appointment.query.get(appointment_id)
        if not appointment:
            return jsonify({'error': 'Appointment not found'}), 404
        
        appointment.payment_status = new_status
        if new_status == 'paid':
            appointment.status = 'confirmed'
            # Send confirmation email when payment is marked as paid
            send_booking_confirmation_email(appointment)
        
        db.session.commit()
        
        return jsonify({
            'message': f'Payment status updated to {new_status}',
            'appointment_id': appointment_id,
            'payment_status': appointment.payment_status,
            'status': appointment.status
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@booking_bp.route('/api/check-payment-status/<int:appointment_id>', methods=['GET'])
def check_payment_status(appointment_id):
    """Check payment status from Stripe and update if needed"""
    try:
        appointment = Appointment.query.get(appointment_id)
        if not appointment:
            return jsonify({'error': 'Appointment not found'}), 404
        
        if not appointment.stripe_payment_intent_id:
            return jsonify({'error': 'No Stripe payment ID found'}), 400
        
        # Configure Stripe
        stripe_secret_key = current_app.config['STRIPE_SECRET_KEY']
        if not stripe_secret_key:
            return jsonify({'error': 'Stripe not configured'}), 500
        
        stripe.api_key = stripe_secret_key
        
        payment_status = 'unknown'
        
        # Check if this is a checkout session
        if appointment.stripe_payment_intent_id.startswith('cs_'):
            session = stripe.checkout.Session.retrieve(appointment.stripe_payment_intent_id)
            payment_status = session.payment_status
            
            if session.payment_status == 'paid' and appointment.payment_status == 'pending':
                appointment.payment_status = 'paid'
                appointment.status = 'confirmed'
                db.session.commit()
                # Send confirmation email
                send_booking_confirmation_email(appointment)
        
        # Check if this is a payment intent
        elif appointment.stripe_payment_intent_id.startswith('pi_'):
            intent = stripe.PaymentIntent.retrieve(appointment.stripe_payment_intent_id)
            payment_status = intent.status
            
            if intent.status == 'succeeded' and appointment.payment_status == 'pending':
                appointment.payment_status = 'paid'
                appointment.status = 'confirmed'
                db.session.commit()
                # Send confirmation email
                send_booking_confirmation_email(appointment)
        
        return jsonify({
            'appointment_id': appointment_id,
            'stripe_payment_id': appointment.stripe_payment_intent_id,
            'stripe_status': payment_status,
            'appointment_payment_status': appointment.payment_status,
            'appointment_status': appointment.status,
            'updated': appointment.payment_status == 'paid'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@booking_bp.route('/api/webhook/stripe', methods=['POST'])
def stripe_webhook():
    """Handle Stripe webhook events"""
    try:
        # Get the webhook secret from config
        webhook_secret = current_app.config.get('STRIPE_WEBHOOK_SECRET')
        if not webhook_secret:
            current_app.logger.error('Stripe webhook secret not configured')
            return jsonify({'error': 'Webhook secret not configured'}), 500
        
        # Get the request payload
        payload = request.get_data()
        sig_header = request.headers.get('Stripe-Signature')
        
        if not sig_header:
            current_app.logger.error('No Stripe signature header')
            return jsonify({'error': 'No signature header'}), 400
        
        # Verify the webhook signature
        try:
            event = stripe.Webhook.construct_event(
                payload, sig_header, webhook_secret
            )
        except ValueError as e:
            current_app.logger.error(f'Invalid payload: {str(e)}')
            return jsonify({'error': 'Invalid payload'}), 400
        except stripe.error.SignatureVerificationError as e:
            current_app.logger.error(f'Invalid signature: {str(e)}')
            return jsonify({'error': 'Invalid signature'}), 400
        
        # Handle the event
        if event['type'] == 'checkout.session.completed':
            session = event['data']['object']
            appointment_id = session.get('metadata', {}).get('appointment_id')
            
            if appointment_id:
                appointment = Appointment.query.get(appointment_id)
                if appointment and appointment.payment_status == 'pending':
                    appointment.payment_status = 'paid'
                    appointment.status = 'confirmed'
                    db.session.commit()
                    
                    # Send confirmation email
                    send_booking_confirmation_email(appointment)
                    current_app.logger.info(f'Payment confirmed via webhook for appointment {appointment_id}')
        
        elif event['type'] == 'payment_intent.succeeded':
            payment_intent = event['data']['object']
            appointment_id = payment_intent.get('metadata', {}).get('appointment_id')
            
            if appointment_id:
                appointment = Appointment.query.get(appointment_id)
                if appointment and appointment.payment_status == 'pending':
                    appointment.payment_status = 'paid'
                    appointment.status = 'confirmed'
                    db.session.commit()
                    
                    # Send confirmation email
                    send_booking_confirmation_email(appointment)
                    current_app.logger.info(f'Payment confirmed via webhook for appointment {appointment_id}')
        
        return jsonify({'status': 'success'})
        
    except Exception as e:
        current_app.logger.error(f'Webhook error: {str(e)}')
        return jsonify({'error': str(e)}), 500