from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for, session
from werkzeug.security import check_password_hash, generate_password_hash
from models.admin_user import AdminUser
from models.user import User
from models.lead import Lead
from models.appointment import Appointment
from models.message import Message
from models.testimonial import Testimonial
from database import db
from datetime import datetime, timedelta
from functools import wraps
import json

admin_bp = Blueprint('admin', __name__)

def admin_required(f):
    """Decorator to require admin login"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_user_id' not in session:
            flash('Please log in to access the admin panel.', 'error')
            return redirect(url_for('admin.login'))
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Admin login page"""
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        
        if not username or not password:
            flash('Please provide both username and password.', 'error')
            return render_template('admin/login.html')
        
        # Check admin credentials
        admin_user = AdminUser.query.filter_by(username=username, is_active=True).first()
        
        if admin_user and admin_user.check_password(password):
            session['admin_user_id'] = admin_user.id
            session['admin_username'] = admin_user.username
            session['admin_role'] = admin_user.role
            
            # Update last login
            admin_user.update_last_login()
            
            flash(f'Welcome back, {admin_user.username}!', 'success')
            return redirect(url_for('admin.dashboard'))
        else:
            flash('Invalid username or password.', 'error')
    
    return render_template('admin/login.html')

@admin_bp.route('/logout')
def logout():
    """Admin logout"""
    session.clear()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('admin.login'))

@admin_bp.route('/dashboard')
@admin_required
def dashboard():
    """Admin dashboard home"""
    # Get dashboard statistics
    stats = {
        'total_leads': Lead.query.count(),
        'new_leads': Lead.query.filter_by(status='new').count(),
        'total_appointments': Appointment.query.count(),
        'upcoming_appointments': Appointment.query.filter(
            Appointment.appointment_date >= datetime.now().date(),
            Appointment.status.in_(['scheduled', 'confirmed'])
        ).count(),
        'unread_messages': Message.query.filter_by(is_read=False, sender_type='user').count(),
        'total_revenue': db.session.query(db.func.sum(Appointment.payment_amount)).filter(
            Appointment.payment_status == 'paid'
        ).scalar() or 0
    }
    
    # Recent activity
    recent_leads = Lead.query.order_by(Lead.created_at.desc()).limit(5).all()
    recent_appointments = Appointment.query.order_by(Appointment.created_at.desc()).limit(5).all()
    recent_messages = Message.query.filter_by(sender_type='user').order_by(Message.created_at.desc()).limit(5).all()
    
    # Service breakdown
    service_stats = db.session.query(
        Lead.service_type, 
        db.func.count(Lead.id).label('count')
    ).group_by(Lead.service_type).all()
    
    return render_template('admin/dashboard.html', 
                         stats=stats, 
                         recent_leads=recent_leads,
                         recent_appointments=recent_appointments,
                         recent_messages=recent_messages,
                         service_stats=service_stats)

@admin_bp.route('/leads')
@admin_required
def leads():
    """Leads management page"""
    # Filters
    status_filter = request.args.get('status', '')
    service_filter = request.args.get('service', '')
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    
    # Build query
    query = Lead.query
    
    if status_filter:
        query = query.filter(Lead.status == status_filter)
    
    if service_filter:
        query = query.filter(Lead.service_type == service_filter)
    
    if date_from:
        date_from_obj = datetime.strptime(date_from, '%Y-%m-%d')
        query = query.filter(Lead.created_at >= date_from_obj)
    
    if date_to:
        date_to_obj = datetime.strptime(date_to, '%Y-%m-%d') + timedelta(days=1)
        query = query.filter(Lead.created_at < date_to_obj)
    
    # Pagination
    page = request.args.get('page', 1, type=int)
    leads_pagination = query.order_by(Lead.created_at.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    # Get unique services for filter dropdown
    services = db.session.query(Lead.service_type.distinct()).all()
    
    return render_template('admin/leads.html', 
                         leads=leads_pagination.items,
                         pagination=leads_pagination,
                         services=[s[0] for s in services],
                         filters={
                             'status': status_filter,
                             'service': service_filter,
                             'date_from': date_from,
                             'date_to': date_to
                         })

@admin_bp.route('/leads/<int:lead_id>')
@admin_required
def lead_detail(lead_id):
    """Individual lead detail page"""
    lead = Lead.query.get_or_404(lead_id)
    return render_template('admin/lead_detail.html', lead=lead)

@admin_bp.route('/api/leads/<int:lead_id>/update', methods=['POST'])
@admin_required
def update_lead(lead_id):
    """Update lead status and notes"""
    try:
        lead = Lead.query.get_or_404(lead_id)
        data = request.get_json()
        
        if 'status' in data:
            lead.status = data['status']
        
        if 'priority' in data:
            lead.priority = data['priority']
        
        if 'notes' in data:
            lead.notes = data['notes']
        
        lead.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Lead updated successfully'})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/appointments')
@admin_required
def appointments():
    """Appointments management page"""
    # Filters
    status_filter = request.args.get('status', '')
    service_filter = request.args.get('service', '')
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    
    # Build query
    query = Appointment.query
    
    if status_filter:
        query = query.filter(Appointment.status == status_filter)
    
    if service_filter:
        query = query.filter(Appointment.service_type == service_filter)
    
    if date_from:
        date_from_obj = datetime.strptime(date_from, '%Y-%m-%d').date()
        query = query.filter(Appointment.appointment_date >= date_from_obj)
    
    if date_to:
        date_to_obj = datetime.strptime(date_to, '%Y-%m-%d').date()
        query = query.filter(Appointment.appointment_date <= date_to_obj)
    
    # Pagination
    page = request.args.get('page', 1, type=int)
    appointments_pagination = query.order_by(Appointment.appointment_date.desc()).paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('admin/appointments.html', 
                         appointments=appointments_pagination.items,
                         pagination=appointments_pagination,
                         filters={
                             'status': status_filter,
                             'service': service_filter,
                             'date_from': date_from,
                             'date_to': date_to
                         })

@admin_bp.route('/api/appointments/<int:appointment_id>/update', methods=['POST'])
@admin_required
def update_appointment(appointment_id):
    """Update appointment status and details"""
    try:
        appointment = Appointment.query.get_or_404(appointment_id)
        data = request.get_json()
        
        if 'status' in data:
            appointment.status = data['status']
        
        if 'notes' in data:
            appointment.notes = data['notes']
        
        if 'appointment_date' in data:
            appointment.appointment_date = datetime.strptime(data['appointment_date'], '%Y-%m-%d').date()
        
        if 'appointment_time' in data:
            appointment.appointment_time = data['appointment_time']
        
        appointment.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Appointment updated successfully'})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/api/appointments/<int:appointment_id>/delete', methods=['DELETE'])
@admin_required
def delete_appointment(appointment_id):
    """Delete an appointment"""
    try:
        appointment = Appointment.query.get_or_404(appointment_id)
        
        # Store appointment details for logging
        appointment_details = {
            'id': appointment.id,
            'customer': appointment.user.name,
            'service': appointment.service_type,
            'date': appointment.appointment_date.strftime('%Y-%m-%d'),
            'time': appointment.appointment_time
        }
        
        # Delete the appointment
        db.session.delete(appointment)
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': f'Appointment for {appointment_details["customer"]} on {appointment_details["date"]} at {appointment_details["time"]} has been deleted successfully.'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/api/appointments/<int:appointment_id>', methods=['GET'])
@admin_required
def get_appointment(appointment_id):
    """Get appointment details for modal"""
    try:
        appointment = Appointment.query.get_or_404(appointment_id)
        
        return jsonify({
            'success': True,
            'appointment': {
                'id': appointment.id,
                'customer_name': appointment.user.name,
                'customer_email': appointment.user.email,
                'customer_phone': appointment.user.phone,
                'service_type': appointment.service_type,
                'appointment_date': appointment.appointment_date.strftime('%Y-%m-%d'),
                'appointment_time': appointment.appointment_time,
                'duration_minutes': appointment.duration_minutes,
                'location_type': appointment.location_type,
                'address': appointment.address,
                'status': appointment.status,
                'payment_status': appointment.payment_status,
                'payment_amount': float(appointment.payment_amount) if appointment.payment_amount else 0,
                'notes': appointment.notes,
                'created_at': appointment.created_at.strftime('%Y-%m-%d %H:%M'),
                'updated_at': appointment.updated_at.strftime('%Y-%m-%d %H:%M')
            }
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/messages')
@admin_required
def messages():
    """Messages management page"""
    # Get unread messages count
    unread_count = Message.query.filter_by(is_read=False, sender_type='user').count()
    
    # Get messages grouped by user/thread
    messages_query = Message.query.order_by(Message.created_at.desc())
    
    # Pagination
    page = request.args.get('page', 1, type=int)
    messages_pagination = messages_query.paginate(
        page=page, per_page=20, error_out=False
    )
    
    return render_template('admin/messages.html', 
                         messages=messages_pagination.items,
                         pagination=messages_pagination,
                         unread_count=unread_count)

@admin_bp.route('/api/messages/<int:message_id>/mark-read', methods=['POST'])
@admin_required
def mark_message_read(message_id):
    """Mark message as read"""
    try:
        message = Message.query.get_or_404(message_id)
        message.mark_as_read()
        
        return jsonify({'success': True, 'message': 'Message marked as read'})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/testimonials')
@admin_required
def testimonials():
    """Testimonials management page"""
    testimonials = Testimonial.query.order_by(Testimonial.created_at.desc()).all()
    return render_template('admin/testimonials.html', testimonials=testimonials)

@admin_bp.route('/api/testimonials', methods=['POST'])
@admin_required
def create_testimonial():
    """Create new testimonial"""
    try:
        data = request.get_json()
        
        testimonial = Testimonial(
            name=data.get('name'),
            service_type=data.get('service_type'),
            content=data.get('content'),
            rating=data.get('rating', 5),
            is_featured=data.get('is_featured', False),
            is_approved=data.get('is_approved', True),
            display_order=data.get('display_order', 0)
        )
        
        db.session.add(testimonial)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Testimonial created successfully'})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/api/testimonials/<int:testimonial_id>', methods=['PUT'])
@admin_required
def update_testimonial(testimonial_id):
    """Update testimonial"""
    try:
        testimonial = Testimonial.query.get_or_404(testimonial_id)
        data = request.get_json()
        
        for field in ['name', 'service_type', 'content', 'rating', 'is_featured', 'is_approved', 'display_order']:
            if field in data:
                setattr(testimonial, field, data[field])
        
        testimonial.updated_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Testimonial updated successfully'})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/api/testimonials/<int:testimonial_id>', methods=['DELETE'])
@admin_required
def delete_testimonial(testimonial_id):
    """Delete testimonial"""
    try:
        testimonial = Testimonial.query.get_or_404(testimonial_id)
        db.session.delete(testimonial)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Testimonial deleted successfully'})
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500