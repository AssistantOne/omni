from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from models.lead import Lead
from models.user import User
from database import db
import json

services_bp = Blueprint('services', __name__)

# Service configurations
SERVICE_CONFIGS = {
    'immigration': {
        'title': 'Immigration Services',
        'description': 'Expert assistance with immigration applications and processes',
        'icon': 'fas fa-passport',
        'disclaimer': True,
        'options': [
            'Adjustment of Status',
            'Asylum Applications',
            'Green Card Renewals',
            'Removal of Conditions',
            'Temporary Protected Status (TPS)',
            'U.S. Citizenship',
            'Family Petitions',
            'Work Authorization',
            'Travel Documents'
        ],
        'faqs': [
            {
                'question': 'What documents do I need for my immigration application?',
                'answer': 'Required documents vary by case type. We will provide a complete checklist during consultation.'
            },
            {
                'question': 'How long does the process take?',
                'answer': 'Processing times vary by USCIS workload and case complexity. We provide current estimates during consultation.'
            }
        ]
    },
    'insurance': {
        'title': 'Insurance Services',
        'description': 'Comprehensive insurance solutions for personal and business protection',
        'icon': 'fas fa-shield-alt',
        'disclaimer': False,
        'options': [
            'Auto Insurance',
            'Renters Insurance',
            'Business Insurance',
            'Motorcycle Insurance',
            'Commercial Auto',
            'General Liability',
            'Professional Liability',
            'Workers Compensation'
        ],
        'faqs': [
            {
                'question': 'What factors affect my insurance rates?',
                'answer': 'Rates depend on coverage type, location, driving record, credit score, and coverage limits.'
            },
            {
                'question': 'Can I get a quote online?',
                'answer': 'Yes! Fill out our quote form and we\'ll provide competitive rates from multiple carriers.'
            }
        ]
    },
    'fingerprinting': {
        'title': 'Ink Fingerprinting',
        'description': 'Professional ink fingerprinting using traditional FD-258 card method',
        'icon': 'fas fa-fingerprint',
        'disclaimer': False,
        'price': 50.00,
        'options': [
            'Employment Background Checks',
            'Licensing Requirements',
            'Security Clearances',
            'Adoption Services',
            'Immigration Purposes',
            'Professional Licensing'
        ],
        'faqs': [
            {
                'question': 'What should I bring to my appointment?',
                'answer': 'Bring valid government-issued photo ID and any specific forms required by your requesting agency.'
            },
            {
                'question': 'How long does the process take?',
                'answer': 'Typical fingerprinting appointments take 10-15 minutes.'
            }
        ]
    },
    'itin': {
        'title': 'ITIN Applications',
        'description': 'Reliable ITIN application and renewal services',
        'icon': 'fas fa-id-card',
        'disclaimer': False,
        'options': [
            'New ITIN Applications',
            'ITIN Renewals',
            'Dependent ITINs',
            'Spouse ITINs',
            'Document Certification',
            'Application Review'
        ],
        'faqs': [
            {
                'question': 'What documents do I need for ITIN application?',
                'answer': 'You need proof of identity and foreign status. We provide a complete document checklist.'
            },
            {
                'question': 'How long does ITIN processing take?',
                'answer': 'IRS processing typically takes 7-11 weeks from the date they receive your application.'
            }
        ]
    },
    'notary': {
        'title': 'Notary Services',
        'description': 'Trusted notary services for document authentication',
        'icon': 'fas fa-stamp',
        'disclaimer': False,
        'options': [
            'Document Notarization',
            'Acknowledgments',
            'Jurats',
            'Copy Certifications',
            'Mobile Notary Services',
            'Witness Services'
        ],
        'faqs': [
            {
                'question': 'What ID do I need for notarization?',
                'answer': 'Valid government-issued photo ID such as driver\'s license, passport, or state ID card.'
            },
            {
                'question': 'Do you offer mobile services?',
                'answer': 'Yes! We provide mobile notary services for your convenience. Additional travel fees apply.'
            }
        ]
    },
    'tax': {
        'title': 'Tax Preparation',
        'description': 'Professional virtual tax preparation services',
        'icon': 'fas fa-calculator',
        'disclaimer': False,
        'options': [
            'Individual Tax Returns',
            'Business Tax Returns',
            'Tax Planning',
            'Amended Returns',
            'Prior Year Returns',
            'Bookkeeping Services'
        ],
        'faqs': [
            {
                'question': 'What documents do I need for tax preparation?',
                'answer': 'Bring W-2s, 1099s, receipts for deductions, and previous year tax return.'
            },
            {
                'question': 'Can you help with tax planning?',
                'answer': 'Yes! We provide year-round tax planning to help minimize your tax liability.'
            }
        ]
    }
}

@services_bp.route('/<service_slug>')
def service_detail(service_slug):
    """Individual service detail page"""
    if service_slug not in SERVICE_CONFIGS:
        return render_template('404.html'), 404
    
    service = SERVICE_CONFIGS[service_slug]
    return render_template('service_detail.html', service=service, service_slug=service_slug)

@services_bp.route('/<service_slug>/intake', methods=['GET', 'POST'])
def service_intake(service_slug):
    """Service intake form"""
    if service_slug not in SERVICE_CONFIGS:
        return render_template('404.html'), 404
    
    service = SERVICE_CONFIGS[service_slug]
    
    if request.method == 'POST':
        try:
            # Get form data
            data = request.form.to_dict()
            
            # Basic validation
            required_fields = ['name', 'email', 'phone']
            for field in required_fields:
                if not data.get(field, '').strip():
                    flash(f'Please provide your {field}.', 'error')
                    return render_template('intake_form.html', service=service, service_slug=service_slug)
            
            # Create or get user
            user = User.query.filter_by(email=data['email']).first()
            if not user:
                user = User(
                    name=data['name'],
                    email=data['email'],
                    phone=data['phone'],
                    language=data.get('language', 'en'),
                    service_requested=service_slug
                )
                db.session.add(user)
                db.session.flush()
            
            # Create lead with form data
            form_data = {
                'source': 'website_intake',
                'service_option': data.get('service_option'),
                'preferred_contact': data.get('preferred_contact', 'email'),
                'message': data.get('message', ''),
                'timeline': data.get('timeline', ''),
                'additional_info': {k: v for k, v in data.items() 
                                 if k not in ['name', 'email', 'phone', 'language']}
            }
            
            lead = Lead(
                user_id=user.id,
                service_type=service_slug,
                status='new',
                priority='high' if service_slug in ['immigration', 'tax'] else 'medium'
            )
            lead.set_form_data(form_data)
            
            db.session.add(lead)
            db.session.commit()
            
            flash('Thank you! Your information has been submitted. We will contact you within 24 hours.', 'success')
            return redirect(url_for('services.service_detail', service_slug=service_slug))
            
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while submitting your information. Please try again.', 'error')
    
    return render_template('intake_form.html', service=service, service_slug=service_slug)

@services_bp.route('/<service_slug>/quote', methods=['GET', 'POST'])
def service_quote(service_slug):
    """Service quote request (mainly for insurance)"""
    if service_slug not in SERVICE_CONFIGS:
        return render_template('404.html'), 404
    
    service = SERVICE_CONFIGS[service_slug]
    
    if request.method == 'POST':
        try:
            data = request.form.to_dict()
            
            # Basic validation
            if not all([data.get('name'), data.get('email'), data.get('phone')]):
                flash('Please fill in all required fields.', 'error')
                return render_template('quote_form.html', service=service, service_slug=service_slug)
            
            # Create or get user
            user = User.query.filter_by(email=data['email']).first()
            if not user:
                user = User(
                    name=data['name'],
                    email=data['email'],
                    phone=data['phone'],
                    service_requested=service_slug
                )
                db.session.add(user)
                db.session.flush()
            
            # Create lead for quote request
            form_data = {
                'type': 'quote_request',
                'source': 'website_quote',
                'quote_details': {k: v for k, v in data.items() 
                                if k not in ['name', 'email', 'phone']}
            }
            
            lead = Lead(
                user_id=user.id,
                service_type=service_slug,
                status='new',
                priority='medium'
            )
            lead.set_form_data(form_data)
            
            db.session.add(lead)
            db.session.commit()
            
            flash('Quote request submitted! We will send you a competitive quote within 24 hours.', 'success')
            return redirect(url_for('services.service_detail', service_slug=service_slug))
            
        except Exception as e:
            db.session.rollback()
            flash('An error occurred. Please try again.', 'error')
    
    return render_template('quote_form.html', service=service, service_slug=service_slug)