#!/usr/bin/env python3
"""
Setup script for OmniQuest Services Admin User
Run this script to create the initial admin user and setup the database.
"""

import os
import sys
from getpass import getpass
from datetime import datetime

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from database import db
from models.admin_user import AdminUser
from models.testimonial import Testimonial

def create_admin_user():
    """Create an admin user interactively"""
    print("\n=== OmniQuest Services Admin Setup ===\n")
    
    # Get admin details
    username = input("Enter admin username (default: admin): ").strip() or "admin"
    email = input("Enter admin email: ").strip()
    
    while not email:
        print("Email is required!")
        email = input("Enter admin email: ").strip()
    
    password = getpass("Enter admin password: ").strip()
    
    while not password or len(password) < 6:
        print("Password must be at least 6 characters!")
        password = getpass("Enter admin password: ").strip()
    
    confirm_password = getpass("Confirm admin password: ").strip()
    
    while password != confirm_password:
        print("Passwords don't match!")
        password = getpass("Enter admin password: ").strip()
        confirm_password = getpass("Confirm admin password: ").strip()
    
    return username, email, password

def create_sample_testimonials():
    """Create sample testimonials"""
    sample_testimonials = [
        {
            'name': 'Maria Rodriguez',
            'service_type': 'immigration',
            'content': 'OmniQuest Services helped me with my green card application. The team was professional, knowledgeable, and made the process so much easier. Highly recommended!',
            'rating': 5,
            'is_featured': True,
            'display_order': 1
        },
        {
            'name': 'John Smith',
            'service_type': 'insurance',
            'content': 'Great service for my auto insurance needs. They found me better coverage at a lower price. Very satisfied with their professionalism.',
            'rating': 5,
            'is_featured': True,
            'display_order': 2
        },
        {
            'name': 'Sarah Johnson',
            'service_type': 'fingerprinting',
            'content': 'Quick and efficient fingerprinting service. The staff was friendly and the process was completed in just a few minutes.',
            'rating': 4,
            'is_featured': True,
            'display_order': 3
        },
        {
            'name': 'Carlos Martinez',
            'service_type': 'tax',
            'content': 'Excellent tax preparation service. They maximized my refund and explained everything clearly. Will definitely use their services again.',
            'rating': 5,
            'is_featured': False,
            'display_order': 4
        },
        {
            'name': 'Lisa Chen',
            'service_type': 'notary',
            'content': 'Professional notary services with mobile options. Very convenient and reliable. The notary was punctual and thorough.',
            'rating': 5,
            'is_featured': False,
            'display_order': 5
        }
    ]
    
    for testimonial_data in sample_testimonials:
        testimonial = Testimonial(**testimonial_data)
        db.session.add(testimonial)
    
    print("✓ Created sample testimonials")

def main():
    """Main setup function"""
    app = create_app()
    
    with app.app_context():
        try:
            # Create all database tables
            print("Creating database tables...")
            db.create_all()
            print("✓ Database tables created")
            
            # Check if admin user already exists
            existing_admin = AdminUser.query.first()
            if existing_admin:
                print(f"\n⚠️  Admin user '{existing_admin.username}' already exists!")
                response = input("Do you want to create another admin user? (y/N): ").strip().lower()
                if response != 'y':
                    print("Setup cancelled.")
                    return
            
            # Create admin user
            username, email, password = create_admin_user()
            
            admin_user = AdminUser(
                username=username,
                email=email,
                role='super_admin'
            )
            admin_user.set_password(password)
            
            db.session.add(admin_user)
            
            # Create sample testimonials if none exist
            if not Testimonial.query.first():
                print("\nCreating sample testimonials...")
                create_sample_testimonials()
            
            # Commit all changes
            db.session.commit()
            
            print(f"\n✅ Setup completed successfully!")
            print(f"Admin user '{username}' created with email '{email}'")
            print(f"\nYou can now log in to the admin panel at: /admin/login")
            print(f"Username: {username}")
            print(f"Password: [hidden]")
            
        except Exception as e:
            db.session.rollback()
            print(f"\n❌ Error during setup: {str(e)}")
            return False
    
    return True

if __name__ == "__main__":
    # Check if .env file exists
    if not os.path.exists('.env'):
        print("⚠️  Warning: .env file not found!")
        print("Please copy config.env.example to .env and configure your environment variables.")
        print("You can still run setup with default SQLite database.")
        response = input("\nContinue with default settings? (y/N): ").strip().lower()
        if response != 'y':
            print("Setup cancelled. Please create .env file first.")
            sys.exit(1)
    
    try:
        success = main()
        if success:
            print("\n🚀 Your OmniQuest Services application is ready!")
            print("\nNext steps:")
            print("1. Start the application: python app.py")
            print("2. Visit: http://localhost:5000")
            print("3. Admin panel: http://localhost:5000/admin/login")
        else:
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n\nSetup cancelled by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {str(e)}")
        sys.exit(1)