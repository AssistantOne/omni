from flask import Blueprint, request, jsonify
from models.user import User
from models.lead import Lead
from models.appointment import Appointment
from models.testimonial import Testimonial
from database import db
from datetime import datetime, date
import json

api_bp = Blueprint('api', __name__)

@api_bp.route('/health')
def health_check():
    """API health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': '1.0.0'
    })

@api_bp.route('/services')
def get_services():
    """Get list of all services"""
    services = [
        {
            'id': 'immigration',
            'name': 'Immigration Services',
            'description': 'Expert assistance with immigration applications and processes',
            'icon': 'fas fa-passport'
        },
        {
            'id': 'insurance',
            'name': 'Insurance Services',
            'description': 'Comprehensive insurance solutions for personal and business protection',
            'icon': 'fas fa-shield-alt'
        },
        {
            'id': 'fingerprinting',
            'name': 'Ink Fingerprinting',
            'description': 'Professional ink fingerprinting services',
            'icon': 'fas fa-fingerprint'
        },
        {
            'id': 'itin',
            'name': 'ITIN Applications',
            'description': 'Reliable ITIN application and renewal services',
            'icon': 'fas fa-id-card'
        },
        {
            'id': 'notary',
            'name': 'Notary Services',
            'description': 'Trusted notary services for document authentication',
            'icon': 'fas fa-stamp'
        },
        {
            'id': 'tax',
            'name': 'Tax Preparation',
            'description': 'Professional virtual tax preparation services',
            'icon': 'fas fa-calculator'
        }
    ]
    
    return jsonify({'services': services})

@api_bp.route('/testimonials')
def get_testimonials():
    """Get approved testimonials"""
    featured_only = request.args.get('featured', 'false').lower() == 'true'
    limit = request.args.get('limit', 10, type=int)
    
    query = Testimonial.query.filter_by(is_approved=True)
    
    if featured_only:
        query = query.filter_by(is_featured=True)
    
    testimonials = query.order_by(Testimonial.display_order.asc()).limit(limit).all()
    
    return jsonify({
        'testimonials': [t.to_dict() for t in testimonials]
    })

@api_bp.route('/contact', methods=['POST'])
def submit_contact():
    """Submit contact form"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'email', 'message']
        for field in required_fields:
            if not data.get(field, '').strip():
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Create or get user
        user = User.query.filter_by(email=data['email']).first()
        if not user:
            user = User(
                name=data['name'],
                email=data['email'],
                phone=data.get('phone', ''),
                language=data.get('language', 'en')
            )
            db.session.add(user)
            db.session.flush()
        
        # Create lead
        form_data = {
            'type': 'api_contact',
            'message': data['message'],
            'source': data.get('source', 'api'),
            'additional_data': {k: v for k, v in data.items() 
                             if k not in ['name', 'email', 'phone', 'message']}
        }
        
        lead = Lead(
            user_id=user.id,
            service_type=data.get('service_type', 'general_inquiry'),
            status='new',
            priority='medium'
        )
        lead.set_form_data(form_data)
        
        db.session.add(lead)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Contact form submitted successfully',
            'lead_id': lead.id
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api_bp.route('/leads', methods=['POST'])
def create_lead():
    """Create a new lead via API"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'email', 'service_type']
        for field in required_fields:
            if not data.get(field, '').strip():
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Create or get user
        user = User.query.filter_by(email=data['email']).first()
        if not user:
            user = User(
                name=data['name'],
                email=data['email'],
                phone=data.get('phone', ''),
                language=data.get('language', 'en'),
                service_requested=data['service_type']
            )
            db.session.add(user)
            db.session.flush()
        
        # Create lead
        form_data = {
            'source': 'api',
            'form_data': data.get('form_data', {}),
            'additional_info': {k: v for k, v in data.items() 
                             if k not in ['name', 'email', 'phone', 'service_type']}
        }
        
        lead = Lead(
            user_id=user.id,
            service_type=data['service_type'],
            status=data.get('status', 'new'),
            priority=data.get('priority', 'medium')
        )
        lead.set_form_data(form_data)
        
        db.session.add(lead)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Lead created successfully',
            'lead': lead.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@api_bp.route('/appointments/availability')
def check_availability():
    """Check appointment availability for a specific date"""
    try:
        date_str = request.args.get('date')
        service_type = request.args.get('service_type', 'general')
        
        if not date_str:
            return jsonify({'error': 'Date parameter required'}), 400
        
        # Parse date
        appointment_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        
        # Check if date is in the past
        if appointment_date < date.today():
            return jsonify({'available': False, 'reason': 'Date is in the past'})
        
        # Check if it's a weekend (for basic business hours)
        if appointment_date.weekday() == 6:  # Sunday
            return jsonify({'available': False, 'reason': 'Closed on Sundays'})
        
        # Get existing appointments for the date
        existing_appointments = Appointment.query.filter_by(
            appointment_date=appointment_date,
            status='scheduled'
        ).all()
        
        # Business hours slots (simplified)
        total_slots = 16 if appointment_date.weekday() < 5 else 8  # Weekday vs Saturday
        booked_slots = len(existing_appointments)
        available_slots = total_slots - booked_slots
        
        return jsonify({
            'available': available_slots > 0,
            'date': date_str,
            'available_slots': available_slots,
            'total_slots': total_slots,
            'booked_slots': booked_slots
        })
        
    except ValueError:
        return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/stats')
def get_stats():
    """Get basic statistics (public data only)"""
    try:
        stats = {
            'total_services': 6,
            'happy_customers': User.query.count(),
            'appointments_completed': Appointment.query.filter_by(status='completed').count(),
            'years_in_business': datetime.now().year - 2020,  # Adjust based on actual start year
            'testimonials_count': Testimonial.query.filter_by(is_approved=True).count()
        }
        
        return jsonify(stats)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/business-hours')
def get_business_hours():
    """Get business hours information"""
    business_hours = {
        'monday': {'open': '10:00', 'close': '18:00', 'is_open': True},
        'tuesday': {'open': '10:00', 'close': '18:00', 'is_open': True},
        'wednesday': {'open': '10:00', 'close': '18:00', 'is_open': True},
        'thursday': {'open': '10:00', 'close': '18:00', 'is_open': True},
        'friday': {'open': '10:00', 'close': '18:00', 'is_open': True},
        'saturday': {'open': '10:00', 'close': '14:00', 'is_open': True},
        'sunday': {'open': None, 'close': None, 'is_open': False}
    }
    
    # Determine current status
    now = datetime.now()
    current_day = now.strftime('%A').lower()
    current_time = now.time()
    
    is_currently_open = False
    if business_hours[current_day]['is_open']:
        open_time = datetime.strptime(business_hours[current_day]['open'], '%H:%M').time()
        close_time = datetime.strptime(business_hours[current_day]['close'], '%H:%M').time()
        is_currently_open = open_time <= current_time <= close_time
    
    return jsonify({
        'business_hours': business_hours,
        'currently_open': is_currently_open,
        'current_time': now.strftime('%H:%M'),
        'current_day': current_day,
        'timezone': 'America/New_York'  # Eastern Time
    })