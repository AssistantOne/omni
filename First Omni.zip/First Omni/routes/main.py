from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from models.testimonial import Testimonial
from models.lead import Lead
from models.user import User
from database import db
import json

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    """Homepage with hero section and service cards"""
    # Get featured testimonials for homepage
    testimonials = Testimonial.query.filter_by(
        is_approved=True, 
        is_featured=True
    ).order_by(Testimonial.display_order.asc()).limit(6).all()
    
    # Service data for homepage cards
    services = [
        {
            'name': 'Immigration',
            'slug': 'immigration',
            'icon': 'fas fa-passport',
            'description': 'Expert assistance with immigration applications, adjustments of status, and citizenship processes.',
            'features': ['Adjustment of Status', 'Asylum Applications', 'Green Card Renewals', 'Citizenship Applications']
        },
        {
            'name': 'Insurance',
            'slug': 'insurance',
            'icon': 'fas fa-shield-alt',
            'description': 'Comprehensive insurance coverage for auto, renters, business, and motorcycle protection.',
            'features': ['Auto Insurance', 'Renters Insurance', 'Business Insurance', 'Motorcycle Insurance']
        },
        {
            'name': 'Ink Fingerprinting',
            'slug': 'fingerprinting',
            'icon': 'fas fa-fingerprint',
            'description': 'Professional ink fingerprinting services using traditional FD-258 card method.',
            'features': ['Employment Screening', 'Background Checks', 'Licensing Requirements', 'Fast & Reliable']
        },
        {
            'name': 'ITIN Applications',
            'slug': 'itin',
            'icon': 'fas fa-id-card',
            'description': 'Stress-free ITIN application and renewal services with accurate paperwork submission.',
            'features': ['New Applications', 'Renewals', 'Document Verification', 'Expert Guidance']
        },
        {
            'name': 'Notary Services',
            'slug': 'notary',
            'icon': 'fas fa-stamp',
            'description': 'Trusted notary services ensuring the legality and authenticity of your important documents.',
            'features': ['Document Notarization', 'Mobile Services', 'Witness Services', 'Legal Authentication']
        },
        {
            'name': 'Tax Preparation',
            'slug': 'tax',
            'icon': 'fas fa-calculator',
            'description': 'Professional virtual tax preparation for individuals and small businesses.',
            'features': ['Individual Returns', 'Business Returns', 'Tax Planning', 'Certified Preparer']
        }
    ]
    
    return render_template('index.html', services=services, testimonials=testimonials)

@main_bp.route('/about')
def about():
    """About page with company information"""
    return render_template('about.html')

@main_bp.route('/contact', methods=['GET', 'POST'])
def contact():
    """Contact page with form submission"""
    if request.method == 'POST':
        try:
            # Get form data
            name = request.form.get('name', '').strip()
            email = request.form.get('email', '').strip()
            phone = request.form.get('phone', '').strip()
            message = request.form.get('message', '').strip()
            agree_texts = request.form.get('agree_texts', 'off') == 'on'
            
            # Validate required fields
            if not all([name, email, message]):
                flash('Please fill in all required fields.', 'error')
                return render_template('contact.html')
            
            # Create or get user
            user = User.query.filter_by(email=email).first()
            if not user:
                user = User(
                    name=name,
                    email=email,
                    phone=phone,
                    language='en'
                )
                db.session.add(user)
                db.session.flush()  # Get user ID
            
            # Create lead
            form_data = {
                'type': 'contact_form',
                'message': message,
                'agree_texts': agree_texts,
                'source': 'website_contact'
            }
            
            lead = Lead(
                user_id=user.id,
                service_type='general_inquiry',
                status='new',
                priority='medium'
            )
            lead.set_form_data(form_data)
            
            db.session.add(lead)
            db.session.commit()
            
            flash('Thank you for your message! We will get back to you within 24 hours.', 'success')
            return redirect(url_for('main.contact'))
            
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while sending your message. Please try again.', 'error')
            return render_template('contact.html')
    
    return render_template('contact.html')

@main_bp.route('/privacy')
def privacy():
    """Privacy policy page"""
    return render_template('privacy.html')

@main_bp.route('/terms')
def terms():
    """Terms of service page"""
    return render_template('terms.html')