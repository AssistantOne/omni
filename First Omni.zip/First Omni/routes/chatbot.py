from flask import Blueprint, request, jsonify, current_app
from models.message import Message
from models.user import User
from database import db
import json
from datetime import datetime, time

chatbot_bp = Blueprint('chatbot', __name__)

# Business hours configuration
BUSINESS_HOURS = {
    'monday': {'start': '10:00', 'end': '18:00'},
    'tuesday': {'start': '10:00', 'end': '18:00'},
    'wednesday': {'start': '10:00', 'end': '18:00'},
    'thursday': {'start': '10:00', 'end': '18:00'},
    'friday': {'start': '10:00', 'end': '18:00'},
    'saturday': {'start': '10:00', 'end': '14:00'},
    'sunday': None  # Closed
}

# Service information for chatbot
SERVICES_INFO = {
    'immigration': {
        'name': 'Immigration Services',
        'description': 'We assist with Adjustment of Status, Asylum, Green Card Renewals, Removal of Conditions, TPS, and U.S. Citizenship applications.',
        'disclaimer': None,
        'common_questions': [
            'What documents do I need?',
            'How long does the process take?',
            'What are your fees?',
            'Can you help with my specific case?'
        ]
    },
    'insurance': {
        'name': 'Insurance Services',
        'description': 'We offer auto, renters, business, and motorcycle insurance with competitive rates and comprehensive coverage options.',
        'disclaimer': None,
        'common_questions': [
            'What types of insurance do you offer?',
            'How can I get a quote?',
            'What factors affect my rates?',
            'Do you offer business insurance?'
        ]
    },
    'fingerprinting': {
        'name': 'Ink Fingerprinting',
        'description': 'Professional ink fingerprinting using traditional FD-258 cards for employment, licensing, and background checks. $50 per service.',
        'disclaimer': 'We do not accept GAPS or Cogent applicants. Please verify your paperwork before booking.',
        'common_questions': [
            'What should I bring to my appointment?',
            'How long does it take?',
            'What is the cost?',
            'Do you accept GAPS applications?'
        ]
    },
    'itin': {
        'name': 'ITIN Services',
        'description': 'Reliable ITIN application and renewal services. We ensure accurate paperwork submission for stress-free processing.',
        'disclaimer': None,
        'common_questions': [
            'What documents do I need?',
            'How long does processing take?',
            'Can you help with renewals?',
            'What are your fees?'
        ]
    },
    'notary': {
        'name': 'Notary Services',
        'description': 'Trusted notary services for document authentication. We offer both in-office and mobile notary services.',
        'disclaimer': None,
        'common_questions': [
            'What ID do I need?',
            'Do you offer mobile services?',
            'What documents can you notarize?',
            'What are your fees?'
        ]
    },
    'tax': {
        'name': 'Tax Preparation',
        'description': 'Professional virtual tax preparation for individuals and small businesses. We help minimize tax liability and maximize refunds.',
        'disclaimer': None,
        'common_questions': [
            'What documents do I need?',
            'Can you help with business taxes?',
            'Do you offer year-round planning?',
            'What are your fees?'
        ]
    }
}

def is_business_hours():
    """Check if current time is within business hours"""
    now = datetime.now()
    day_name = now.strftime('%A').lower()
    
    if day_name not in BUSINESS_HOURS or not BUSINESS_HOURS[day_name]:
        return False
    
    current_time = now.time()
    start_time = time.fromisoformat(BUSINESS_HOURS[day_name]['start'])
    end_time = time.fromisoformat(BUSINESS_HOURS[day_name]['end'])
    
    return start_time <= current_time <= end_time

def get_openai_response(message, context=None):
    """Get response from OpenAI API"""
    try:
        # Get API key from config (loaded from .env file)
        api_key = current_app.config.get('OPENAI_API_KEY')
        
        # Check if API key is set
        if not api_key:
            print("ERROR: OpenAI API key is not set in .env file")
            return "I'm sorry, the chatbot is not properly configured. Please contact us directly at (404) 474-3125 for assistance."
        
        print(f"Using OpenAI API key from .env: {api_key[:20]}...")
        
        # Use the new OpenAI client syntax for version 1.0.0+
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        
        system_prompt = """You are a helpful customer service assistant for OmniQuest Services, a professional service provider in Conyers, Georgia.

COMPANY INFORMATION:
- Business Name: OmniQuest Services
- Location: 1540 Highway 138 SE, Suite 4L, Conyers, GA 30013
- Phone: (404) 474-3125
- Email: info@omniquestservices.com
- Website: www.omniquestservices.com

BUSINESS HOURS:
- Monday-Friday: 10:00am-6:00pm
- Saturday: 10:00am-2:00pm
- Sunday: Closed

SERVICES OFFERED:

1. IMMIGRATION SERVICES:
   - Adjustment of Status
   - Asylum applications
   - Green Card Renewals
   - Removal of Conditions
   - TPS (Temporary Protected Status)
   - U.S. Citizenship applications
   - DISCLAIMER: We are not a law firm and do not offer legal advice

2. INSURANCE SERVICES:
   - Auto Insurance
   - Renters Insurance
   - Business Insurance
   - Motorcycle Insurance
   - Competitive rates and comprehensive coverage

3. INK FINGERPRINTING:
   - Professional ink fingerprinting using FD-258 cards
   - For employment, licensing, and background checks
   - Cost: $50 per service
   - DISCLAIMER: We do not accept GAPS or Cogent applicants

4. ITIN SERVICES:
   - ITIN application and renewal services
   - Accurate paperwork submission
   - Stress-free processing

5. NOTARY SERVICES:
   - Document authentication
   - In-office and mobile notary services
   - DISCLAIMER: We are not a law firm and do not offer legal advice

6. TAX PREPARATION:
   - Professional virtual tax preparation
   - Individual and small business taxes
   - Tax liability minimization
   - Refund maximization

IMPORTANT GUIDELINES:
- Always be professional, helpful, and concise
- If asked about legal advice, remind customers we don't provide legal advice and suggest consulting an attorney
- For fingerprinting, always mention we don't accept GAPS or Cogent applicants
- Direct customers to book appointments or contact us for detailed assistance
- Use emojis sparingly but appropriately to make responses friendly
- Keep responses focused on our services and capabilities
- If outside business hours, suggest calling or emailing for immediate assistance
- Always provide our contact information when relevant

RESPONSE STYLE:
- Professional yet friendly
- Concise but informative
- Use bullet points when listing multiple items
- Include relevant contact information when appropriate
- Suggest booking appointments for detailed consultations"""
        
        messages = [
            {"role": "system", "content": system_prompt}
        ]
        
        if context:
            messages.append({"role": "assistant", "content": f"Context: {context}"})
        
        messages.append({"role": "user", "content": message})
        
        print(f"Sending request to OpenAI with message: {message[:50]}...")
        
        # Use the new OpenAI client syntax
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=messages,
            max_tokens=400,
            temperature=0.7
        )
        
        result = response.choices[0].message.content.strip()
        print(f"OpenAI response received: {result[:50]}...")
        return result
        
    except Exception as e:
        print(f"OpenAI API Error: {str(e)}")
        return "I'm sorry, I'm having trouble processing your request right now. Please contact us directly at (404) 474-3125 or info@omniquestservices.com for immediate assistance."

@chatbot_bp.route('/widget')
def chatbot_widget():
    """Render chatbot widget HTML"""
    return '''
    <div id="omniquest-chatbot" style="position: fixed; bottom: 20px; right: 20px; z-index: 1000;">
        <div id="chat-button" style="width: 60px; height: 60px; background: #007bff; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 12px rgba(0,0,0,0.3);">
            <i class="fas fa-comments" style="color: white; font-size: 24px;"></i>
        </div>
        <div id="chat-window" style="display: none; width: 350px; height: 500px; background: white; border-radius: 10px; box-shadow: 0 8px 24px rgba(0,0,0,0.3); position: absolute; bottom: 80px; right: 0;">
            <!-- Chat content will be loaded here -->
        </div>
    </div>
    '''

@chatbot_bp.route('/api/start', methods=['POST'])
def start_chat():
    """Initialize chat session"""
    try:
        # Generate greeting message
        if is_business_hours():
            greeting = """👋 Hi! Welcome to OmniQuest Services! 

I'm here to help you with information about our services. How can I assist you today?

Our services:
🏛️ Immigration Services
🛡️ Insurance (Auto, Renters, Business, Motorcycle)
👆 Ink Fingerprinting  
🆔 ITIN Applications
📋 Notary Services
🧮 Tax Preparation

What would you like to know about?"""
        else:
            greeting = """👋 Hi! Welcome to OmniQuest Services!

Thank you for visiting! We're currently outside our business hours:
📅 Monday-Friday: 10:00am-6:00pm
📅 Saturday: 10:00am-2:00pm
📅 Sunday: Closed

I can still help answer questions about our services, or you can:
📞 Call us at (404) 474-3125
📧 Email: info@omniquestservices.com

What would you like to know about our services?"""
        
        return jsonify({
            'message': greeting,
            'type': 'greeting',
            'business_hours': is_business_hours(),
            'session_id': f"chat_{datetime.now().timestamp()}"
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@chatbot_bp.route('/api/message', methods=['POST'])
def handle_message():
    """Handle incoming chat messages"""
    try:
        data = request.get_json()
        user_message = data.get('message', '').strip()
        session_id = data.get('session_id')
        user_email = data.get('user_email')
        language = data.get('language', 'en')
        
        if not user_message:
            return jsonify({'error': 'Message is required'}), 400
        
        # Store user message if user email provided
        user_id = None
        if user_email:
            user = User.query.filter_by(email=user_email).first()
            if user:
                user_id = user.id
                
                # Store user message
                message = Message(
                    user_id=user_id,
                    sender_type='user',
                    content=user_message,
                    thread_id=session_id
                )
                db.session.add(message)
        
        # Check for service-specific keywords
        service_context = None
        for service_key, service_info in SERVICES_INFO.items():
            if service_key.lower() in user_message.lower() or service_info['name'].lower() in user_message.lower():
                service_context = f"User is asking about {service_info['name']}: {service_info['description']}"
                if service_info['disclaimer']:
                    service_context += f"\nImportant: {service_info['disclaimer']}"
                break
        
        # Generate AI response
        ai_response = get_openai_response(user_message, service_context)
        
        # Add business hours message if outside hours
        if not is_business_hours() and ('appointment' in user_message.lower() or 'book' in user_message.lower()):
            ai_response += "\n\n📞 For immediate assistance, please call us at (404) 474-3125 or email info@omniquestservices.com"
        
        # Store AI response if user email provided
        if user_id:
            ai_message = Message(
                user_id=user_id,
                sender_type='chatbot',
                content=ai_response,
                thread_id=session_id
            )
            db.session.add(ai_message)
            db.session.commit()
        
        # Suggest actions based on context
        suggested_actions = []
        if any(keyword in user_message.lower() for keyword in ['book', 'appointment', 'schedule']):
            suggested_actions.append({
                'text': '📅 Book Appointment',
                'action': 'book_appointment',
                'url': '/booking'
            })
        
        if any(keyword in user_message.lower() for keyword in ['quote', 'price', 'cost', 'insurance']):
            suggested_actions.append({
                'text': '💰 Get Quote',
                'action': 'get_quote',
                'url': '/services/insurance/quote'
            })
        
        return jsonify({
            'message': ai_response,
            'type': 'response',
            'suggested_actions': suggested_actions,
            'business_hours': is_business_hours()
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@chatbot_bp.route('/api/escalate', methods=['POST'])
def escalate_to_human():
    """Escalate conversation to human agent"""
    try:
        data = request.get_json()
        user_email = data.get('user_email')
        message = data.get('message', 'User requested to speak with a human agent')
        session_id = data.get('session_id')
        
        if user_email:
            # Create or get user
            user = User.query.filter_by(email=user_email).first()
            if not user:
                user = User(
                    name=data.get('name', 'Chat User'),
                    email=user_email,
                    phone=data.get('phone', ''),
                    language=data.get('language', 'en')
                )
                db.session.add(user)
                db.session.flush()
            
            # Store escalation message
            escalation_message = Message(
                user_id=user.id,
                sender_type='system',
                content=f"ESCALATION REQUEST: {message}",
                thread_id=session_id,
                message_metadata=json.dumps({'escalated': True, 'timestamp': datetime.now().isoformat()})
            )
            db.session.add(escalation_message)
            db.session.commit()
        
        response_message = """🙋‍♀️ I've connected you with our team! 

You can reach us:
📞 Phone: (404) 474-3125
📧 Email: info@omniquestservices.com
🏢 Office: 1540 Highway 138 SE, Suite 4L, Conyers, GA 30013

Business Hours:
📅 Monday-Friday: 10:00am-6:00pm
📅 Saturday: 10:00am-2:00pm

We'll get back to you as soon as possible!"""
        
        return jsonify({
            'message': response_message,
            'type': 'escalation',
            'success': True
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500