# 🌟 OmniQuest Services - Full-Stack Web Application

A comprehensive web application for **OmniQuest Services**, offering professional immigration, insurance, notary, and tax services in Conyers, GA. Built with **Flask** backend and responsive frontend with **AI chatbot integration**.

![OmniQuest Services](https://img.shields.io/badge/OmniQuest-Services-blue?style=for-the-badge)
![Flask](https://img.shields.io/badge/Flask-2.3.3-green?style=flat-square)
![Python](https://img.shields.io/badge/Python-3.8+-blue?style=flat-square)
![Bootstrap](https://img.shields.io/badge/Bootstrap-5.3-purple?style=flat-square)
![Stripe](https://img.shields.io/badge/Stripe-Payment-orange?style=flat-square)

## 🚀 Features

### 🎯 Core Services
- **Immigration Services** - Application assistance and guidance
- **Insurance Solutions** - Auto, renters, business, motorcycle coverage
- **Ink Fingerprinting** - Professional FD-258 card services
- **ITIN Applications** - New applications and renewals
- **Notary Services** - Document authentication (mobile available)
- **Tax Preparation** - Individual and business tax services

### 💻 Technical Features
- **Responsive Design** - Optimized for iPhone 14 Pro Max and all devices
- **AI Chatbot** - ChatGPT-powered customer service
- **Online Booking** - Calendar integration with Stripe payments
- **Admin Dashboard** - Complete business management system
- **Email Automation** - Confirmation and reminder emails
- **Lead Management** - Customer relationship tracking
- **Mobile-First** - Progressive web app capabilities

### 🔐 Security & Performance
- **Secure Authentication** - Admin panel with session management
- **Payment Processing** - PCI-compliant Stripe integration
- **Data Protection** - Encrypted sensitive information
- **VPS Ready** - Production deployment configuration
- **SSL Support** - HTTPS with Let's Encrypt integration

## 📋 Quick Start

### Prerequisites
- Python 3.8+
- Git
- Modern web browser

### Installation

1. **Clone & Setup**
```bash
# Download all project files to your directory
cd your-project-directory

# Install dependencies
pip install -r requirements.txt
```

2. **Environment Configuration**
```bash
# Copy environment template
cp config.env.example .env

# Edit configuration (required)
nano .env  # or use your preferred editor
```

3. **Database & Admin Setup**
```bash
# Run setup script
python setup_admin.py

# Follow the prompts to create admin user
```

4. **Start Application**
```bash
# Development mode
python app.py

# Production mode (with Gunicorn)
gunicorn -c gunicorn.conf.py app:app
```

5. **Access Application**
- 🌐 **Website**: http://localhost:5000
- 🔧 **Admin Panel**: http://localhost:5000/admin/login
- 📱 **Mobile Optimized**: Works on all devices

## 🏗️ Project Structure

```
omniquest-services/
├── 📁 models/              # Database models
│   ├── user.py            # User model
│   ├── lead.py            # Lead management
│   ├── appointment.py     # Booking system
│   ├── message.py         # Chat messages
│   ├── testimonial.py     # Customer reviews
│   └── admin_user.py      # Admin authentication
├── 📁 routes/              # Application routes
│   ├── main.py            # Homepage & general pages
│   ├── services.py        # Service-specific pages
│   ├── booking.py         # Appointment booking
│   ├── chatbot.py         # AI chat integration
│   ├── admin.py           # Admin dashboard
│   └── api.py             # API endpoints
├── 📁 templates/           # HTML templates
│   ├── base.html          # Base template
│   ├── index.html         # Homepage
│   ├── service_detail.html # Service pages
│   ├── intake_form.html   # Lead capture forms
│   ├── booking/           # Booking system templates
│   └── admin/             # Admin panel templates
├── 📁 utils/               # Utility functions
│   └── email_service.py   # Email automation
├── app.py                 # Main Flask application
├── setup_admin.py         # Database setup script
├── requirements.txt       # Python dependencies
├── config.env.example     # Environment template
├── DEPLOYMENT_GUIDE.md    # Production deployment
└── README.md              # This file
```

## 🛠️ Configuration

### Required Environment Variables

```bash
# Flask Configuration
SECRET_KEY=your-secure-secret-key
FLASK_ENV=development  # or 'production'
DATABASE_URL=sqlite:///omniquest.db

# Email Settings (Gmail example)
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password

# Stripe Payment Processing
STRIPE_PUBLISHABLE_KEY=pk_test_your_key
STRIPE_SECRET_KEY=sk_test_your_key

# OpenAI Chatbot
OPENAI_API_KEY=your-openai-key

# Admin Settings
ADMIN_EMAIL=admin@omniquestservices.com
```

### Service Configuration

Each service can be customized in `routes/services.py`:

```python
SERVICE_CONFIGS = {
    'immigration': {
        'title': 'Immigration Services',
        'price': 150.00,  # Consultation fee
        'duration': 90,   # Minutes
        'disclaimer': True
    },
    'fingerprinting': {
        'title': 'Ink Fingerprinting',
        'price': 50.00,   # Service fee
        'duration': 30    # Minutes
    }
    # ... more services
}
```

## 🎨 Design & Branding

### Color Scheme
- **Primary Blue**: `#0056d3` (Omni Blue)
- **Secondary Blue**: `#4a90e2` (Light Blue)
- **Accent Orange**: `#ff6b35` (Omni Orange)
- **Success Green**: `#2ecc71` (Omni Green)
- **Purple**: `#8e44ad` (Omni Purple)

### Brand Features
- **Mobile-First Design** - Responsive on all devices
- **OmniQuest Colors** - Consistent brand identity
- **Professional Layout** - Clean, modern interface
- **Accessibility** - WCAG compliant design
- **Fast Loading** - Optimized assets and code

## 🤖 AI Chatbot Features

The integrated chatbot provides:

- **Service Information** - Answers about all 6 services
- **Business Hours** - Real-time availability status  
- **Lead Capture** - Seamless customer information collection
- **Multilingual Support** - English and Spanish
- **Escalation Options** - Direct contact when needed
- **Context Awareness** - Service-specific responses

### Chatbot Configuration

```javascript
// Customize chatbot behavior
const CHATBOT_CONFIG = {
    greeting_delay: 3000,     // Show greeting after 3 seconds
    languages: ['en', 'es'],  // Supported languages
    business_hours: {         // Operating hours
        monday: { start: '10:00', end: '18:00' },
        // ... other days
    }
};
```

## 💳 Payment Integration

### Stripe Setup

1. **Create Stripe Account** at https://stripe.com
2. **Get API Keys** from Dashboard → Developers → API Keys
3. **Configure Webhooks**:
   - Endpoint: `https://yourdomain.com/booking/api/webhook/stripe`
   - Events: `payment_intent.succeeded`

### Supported Services
- **Immigration Consultation**: $150
- **Ink Fingerprinting**: $50  
- **ITIN Applications**: $75
- **Tax Consultation**: $100
- **Notary Services**: $15/document
- **Insurance**: Free consultation

## 📊 Admin Dashboard

### Features
- **Lead Management** - Track and convert prospects
- **Appointment Scheduling** - Calendar integration
- **Message Center** - Customer communication
- **Testimonial Management** - Customer reviews
- **Revenue Analytics** - Business insights
- **User Management** - Customer database

### Access Levels
- **Super Admin** - Full system access
- **Admin** - Standard management features

## 📧 Email System

### Automated Emails
- **Appointment Confirmations** - Instant booking confirmations
- **Reminder Emails** - 24-hour appointment reminders  
- **Lead Notifications** - Admin alerts for new leads
- **Contact Form** - Customer inquiry notifications

### Email Templates
All emails use responsive HTML templates with:
- **Brand Consistency** - OmniQuest colors and styling
- **Mobile Optimization** - Perfect on all devices
- **Professional Design** - Clean, modern layout

## 🚀 Deployment

### Development Deployment
```bash
# Quick start for development
python setup_admin.py
python app.py
```

### Production Deployment
See **[DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)** for complete VPS setup:

- ✅ Ubuntu 20.04+ VPS setup
- ✅ Nginx + Gunicorn configuration  
- ✅ PostgreSQL database setup
- ✅ SSL certificate with Let's Encrypt
- ✅ Supervisor process management
- ✅ Security hardening
- ✅ Backup strategies

### Docker Deployment (Optional)
```bash
# Build container
docker build -t omniquest-services .

# Run with environment
docker run -p 5000:5000 --env-file .env omniquest-services
```

## 🔧 API Endpoints

### Public APIs
- `GET /api/services` - List all services
- `GET /api/testimonials` - Customer reviews
- `POST /api/contact` - Contact form submission
- `GET /api/business-hours` - Operating hours

### Booking APIs  
- `GET /booking/api/available-slots` - Available time slots
- `POST /booking/api/create-payment-intent` - Stripe payment
- `POST /booking/api/confirm-booking` - Confirm appointment

### Admin APIs (Protected)
- `POST /admin/api/leads/{id}/update` - Update lead status
- `POST /admin/api/appointments/{id}/update` - Modify appointment
- `POST /admin/api/messages/{id}/mark-read` - Mark message read

## 📱 Mobile Optimization

### iPhone 14 Pro Max Features
- **Responsive Breakpoints** - Perfect scaling
- **Touch-Friendly UI** - Large tap targets
- **Fast Loading** - Optimized for mobile networks
- **Offline Capability** - Basic offline functionality
- **App-Like Experience** - PWA capabilities

### Cross-Device Testing
- ✅ iPhone 14 Pro Max (primary target)
- ✅ iPad tablets
- ✅ Android phones
- ✅ Desktop browsers
- ✅ Accessibility standards

## 🔒 Security Features

### Data Protection
- **Encrypted Passwords** - Werkzeug password hashing
- **Session Security** - Secure cookie handling
- **CSRF Protection** - Form security tokens
- **Input Validation** - Sanitized user inputs
- **SQL Injection Prevention** - SQLAlchemy ORM

### Access Control
- **Admin Authentication** - Secure login system
- **Role-Based Access** - Different permission levels
- **Session Management** - Automatic timeouts
- **Audit Logging** - Track admin actions

## 📈 Analytics & Monitoring

### Built-in Analytics
- **Lead Conversion Tracking** - Measure effectiveness
- **Revenue Analytics** - Business performance
- **Service Popularity** - Most requested services
- **Response Times** - Customer service metrics

### Log Files
- **Application Logs** - Error tracking and debugging
- **Access Logs** - User behavior analysis
- **Admin Activity** - Security monitoring
- **Email Delivery** - Communication tracking

## 🛠️ Customization

### Adding New Services
1. **Update Service Config** in `routes/services.py`
2. **Add Route Handler** for service-specific logic
3. **Create Templates** for service pages
4. **Update Navigation** in base template

### Modifying Branding
1. **Update CSS Variables** in `templates/base.html`
2. **Replace Logo/Icons** in static files
3. **Modify Brand Colors** throughout templates
4. **Update Business Information** in templates

### Extending Functionality
- **Add New Models** in `models/` directory
- **Create API Endpoints** in `routes/api.py`
- **Implement Webhooks** for integrations
- **Add Background Tasks** with Celery

## 🆘 Troubleshooting

### Common Issues

**Database Connection Error**
```bash
# Check database status
sudo systemctl status postgresql

# Verify connection string in .env
DATABASE_URL=postgresql://user:password@localhost/dbname
```

**Email Not Sending**
```bash
# Verify SMTP settings
MAIL_SERVER=smtp.gmail.com
MAIL_USE_TLS=True

# Check Gmail app password (not regular password)
```

**Stripe Webhook Failing**
```bash
# Verify webhook URL
https://yourdomain.com/booking/api/webhook/stripe

# Check Stripe webhook secret
STRIPE_WEBHOOK_SECRET=whsec_your_secret
```

**Chatbot Not Responding**
```bash
# Verify OpenAI API key
OPENAI_API_KEY=your_valid_key

# Check API usage limits
```

## 📞 Support & Contact

- **Email**: admin@omniquestservices.com
- **Phone**: (404) 474-3125  
- **Address**: 1540 Highway 138 SE, Suite 4L, Conyers, GA 30013
- **Hours**: Monday-Friday 10am-6pm, Saturday 10am-2pm

## 📄 License

This project is proprietary software developed for OmniQuest Services. All rights reserved.

## 🙏 Acknowledgments

- **Flask Framework** - Python web framework
- **Bootstrap** - CSS framework
- **Stripe** - Payment processing
- **OpenAI** - AI chatbot capabilities
- **Font Awesome** - Icon library

---

### 🎉 **Your OmniQuest Services application is ready for production!**

For detailed deployment instructions, see **[DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)**