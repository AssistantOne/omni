#!/usr/bin/env python3
"""
Simple Stripe Setup Script
This script helps you create a .env file with your Stripe keys
"""

import os

def setup_stripe():
    """Setup Stripe environment variables"""
    print("💳 Stripe Setup for OmniQuest Services")
    print("=" * 40)
    
    # Check if .env already exists
    if os.path.exists('.env'):
        response = input("⚠️  .env file already exists. Overwrite? (y/N): ")
        if response.lower() != 'y':
            print("Setup cancelled.")
            return
    
    print("\n📝 Please provide your Stripe API keys:")
    print("(Get these from https://dashboard.stripe.com/apikeys)\n")
    
    # Get Stripe keys
    publishable_key = input("Stripe Publishable Key (pk_test_...): ").strip()
    secret_key = input("Stripe Secret Key (sk_test_...): ").strip()
    
    if not publishable_key or not secret_key:
        print("❌ Both keys are required!")
        return
    
    # Create .env content
    env_content = f"""# Stripe Configuration
STRIPE_PUBLISHABLE_KEY={publishable_key}
STRIPE_SECRET_KEY={secret_key}

# Other required environment variables (you can update these later)
SECRET_KEY=your-secret-key-here-change-in-production
FLASK_ENV=development
DEBUG=True
DATABASE_URL=sqlite:///omniquest.db
"""
    
    # Write .env file
    with open('.env', 'w') as f:
        f.write(env_content)
    
    print("\n✅ .env file created successfully!")
    print("\n📋 Next steps:")
    print("1. Review the .env file and update other values if needed")
    print("2. Restart your Flask application: python app.py")
    print("3. Test the booking system with a service that has a price > $0")
    print("\n🔒 Security Note: Keep your .env file secure and never commit it to version control!")

if __name__ == '__main__':
    setup_stripe() 