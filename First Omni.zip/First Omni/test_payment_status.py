#!/usr/bin/env python3
"""
Test script to check and update payment status for appointments
"""

import requests
import json
import sys

def check_payment_status(appointment_id, base_url="http://localhost:5000"):
    """Check payment status for an appointment"""
    try:
        response = requests.get(f"{base_url}/booking/api/check-payment-status/{appointment_id}")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Payment Status Check for Appointment {appointment_id}:")
            print(f"   Stripe Payment ID: {data['stripe_payment_id']}")
            print(f"   Stripe Status: {data['stripe_status']}")
            print(f"   Appointment Payment Status: {data['appointment_payment_status']}")
            print(f"   Appointment Status: {data['appointment_status']}")
            print(f"   Updated: {data['updated']}")
            return data
        else:
            print(f"❌ Error checking payment status: {response.status_code}")
            print(response.text)
            return None
    except Exception as e:
        print(f"❌ Exception: {str(e)}")
        return None

def update_payment_status(appointment_id, status="paid", base_url="http://localhost:5000"):
    """Manually update payment status for an appointment"""
    try:
        response = requests.post(
            f"{base_url}/booking/api/update-payment-status/{appointment_id}",
            json={"status": status},
            headers={"Content-Type": "application/json"}
        )
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Payment Status Updated for Appointment {appointment_id}:")
            print(f"   New Payment Status: {data['payment_status']}")
            print(f"   New Status: {data['status']}")
            return data
        else:
            print(f"❌ Error updating payment status: {response.status_code}")
            print(response.text)
            return None
    except Exception as e:
        print(f"❌ Exception: {str(e)}")
        return None

def main():
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python test_payment_status.py check <appointment_id>")
        print("  python test_payment_status.py update <appointment_id> [status]")
        print("  python test_payment_status.py <appointment_id>")
        sys.exit(1)
    
    if sys.argv[1] == "check":
        if len(sys.argv) < 3:
            print("❌ Please provide appointment ID")
            sys.exit(1)
        appointment_id = int(sys.argv[2])
        check_payment_status(appointment_id)
    
    elif sys.argv[1] == "update":
        if len(sys.argv) < 3:
            print("❌ Please provide appointment ID")
            sys.exit(1)
        appointment_id = int(sys.argv[2])
        status = sys.argv[3] if len(sys.argv) > 3 else "paid"
        update_payment_status(appointment_id, status)
    
    else:
        # Default: check payment status
        try:
            appointment_id = int(sys.argv[1])
            check_payment_status(appointment_id)
        except ValueError:
            print("❌ Invalid appointment ID")
            sys.exit(1)

if __name__ == "__main__":
    main() 