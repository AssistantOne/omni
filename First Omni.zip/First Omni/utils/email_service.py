from flask import current_app, render_template_string
from flask_mail import Message
from app import mail
import threading

def send_async_email(app, msg):
    """Send email asynchronously"""
    with app.app_context():
        try:
            mail.send(msg)
        except Exception as e:
            current_app.logger.error(f"Failed to send email: {str(e)}")

def send_email(subject, recipients, text_body=None, html_body=None, sender=None):
    """Send email with optional async processing"""
    try:
        msg = Message(
            subject=subject,
            recipients=recipients if isinstance(recipients, list) else [recipients],
            body=text_body,
            html=html_body,
            sender=sender or current_app.config['MAIL_DEFAULT_SENDER']
        )
        
        # Send asynchronously
        thread = threading.Thread(
            target=send_async_email,
            args=(current_app._get_current_object(), msg)
        )
        thread.start()
        
        return True
    except Exception as e:
        current_app.logger.error(f"Error preparing email: {str(e)}")
        return False

def send_appointment_confirmation(appointment):
    """Send appointment confirmation email"""
    subject = f"Appointment Confirmation - OmniQuest Services"
    
    html_template = """
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>Appointment Confirmation</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #0056d3, #4a90e2); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: white; padding: 30px; border: 1px solid #ddd; }
            .footer { background: #f8f9fa; padding: 20px; text-align: center; border-radius: 0 0 10px 10px; }
            .appointment-details { background: #f8f9fa; padding: 20px; border-radius: 10px; margin: 20px 0; }
            .detail-row { display: flex; justify-content: space-between; margin-bottom: 10px; }
            .btn { background: #0056d3; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; display: inline-block; }
            .important-note { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 20px 0; }
            .contact-info { background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>✅ Appointment Confirmed!</h1>
                <p>Thank you for booking with OmniQuest Services</p>
            </div>
            
            <div class="content">
                <p>Dear {{ appointment.user.name }},</p>
                
                <p><strong>Great news! Your appointment has been successfully confirmed.</strong> We're looking forward to serving you.</p>
                
                <div class="appointment-details">
                    <h3>📅 Appointment Details</h3>
                    <div class="detail-row">
                        <strong>Service:</strong>
                        <span>{{ appointment.service_type.title() }}</span>
                    </div>
                    <div class="detail-row">
                        <strong>Date:</strong>
                        <span>{{ appointment.appointment_date.strftime('%A, %B %d, %Y') }}</span>
                    </div>
                    <div class="detail-row">
                        <strong>Time:</strong>
                        <span>{{ appointment.appointment_time }}</span>
                    </div>
                    <div class="detail-row">
                        <strong>Duration:</strong>
                        <span>{{ appointment.duration_minutes }} minutes</span>
                    </div>
                    <div class="detail-row">
                        <strong>Location:</strong>
                        <span>
                            {% if appointment.location_type == 'office' %}
                                🏢 OmniQuest Services Office<br>
                                1540 Highway 138 SE, Suite 4L<br>
                                Conyers, GA 30013
                            {% else %}
                                🚗 {{ appointment.address or 'Mobile Service' }}
                            {% endif %}
                        </span>
                    </div>
                    {% if appointment.payment_amount %}
                    <div class="detail-row">
                        <strong>Amount Paid:</strong>
                        <span>${{ "%.2f"|format(appointment.payment_amount) }}</span>
                    </div>
                    {% endif %}
                    <div class="detail-row">
                        <strong>Confirmation ID:</strong>
                        <span>#{{ appointment.id }}</span>
                    </div>
                </div>
                
                <div class="important-note">
                    <h3>⚠️ Important Reminders</h3>
                    <ul>
                        <li><strong>Please arrive 10 minutes early</strong> to complete any necessary paperwork</li>
                        <li><strong>Bring a valid government-issued photo ID</strong> (driver's license, passport, etc.)</li>
                        <li><strong>Cancel or reschedule at least 24 hours in advance</strong> if needed</li>
                    </ul>
                </div>
                
                <h3>📋 What to Bring</h3>
                <ul>
                    {% if appointment.service_type == 'fingerprinting' %}
                    <li>Valid government-issued photo ID</li>
                    <li>Any specific forms required by your requesting agency</li>
                    <li>Payment receipt (if not already paid online)</li>
                    {% elif appointment.service_type == 'notary' %}
                    <li>Valid government-issued photo ID</li>
                    <li>Documents to be notarized (unsigned)</li>
                    <li>Payment receipt (if not already paid online)</li>
                    {% elif appointment.service_type == 'immigration' %}
                    <li>All relevant immigration documents</li>
                    <li>Valid identification</li>
                    <li>Any previous correspondence with USCIS</li>
                    <li>Payment receipt (if not already paid online)</li>
                    {% elif appointment.service_type == 'itin' %}
                    <li>Proof of identity documents</li>
                    <li>Proof of foreign status</li>
                    <li>Tax return or other reason for ITIN</li>
                    <li>Payment receipt (if not already paid online)</li>
                    {% elif appointment.service_type == 'tax' %}
                    <li>W-2s, 1099s, and other tax documents</li>
                    <li>Previous year tax return</li>
                    <li>Receipts for deductions</li>
                    <li>Payment receipt (if not already paid online)</li>
                    {% else %}
                    <li>Any relevant documents</li>
                    <li>Valid identification</li>
                    <li>Payment receipt (if not already paid online)</li>
                    {% endif %}
                </ul>
                
                <div class="contact-info">
                    <h3>📞 Need to Make Changes?</h3>
                    <p>If you need to reschedule, cancel, or have any questions, please contact us:</p>
                <ul>
                        <li><strong>Phone:</strong> <a href="tel:+14044743125">(404) 474-3125</a></li>
                        <li><strong>Email:</strong> <a href="mailto:info@omniquestservices.com">info@omniquestservices.com</a></li>
                        <li><strong>Business Hours:</strong> Monday-Friday 10:00 AM - 6:00 PM, Saturday 10:00 AM - 2:00 PM</li>
                </ul>
                </div>
                
                <p><strong>We look forward to serving you!</strong></p>
                
                <p>Best regards,<br>The OmniQuest Services Team</p>
            </div>
            
            <div class="footer">
                <p><strong>OmniQuest Services</strong></p>
                <p>1540 Highway 138 SE, Suite 4L, Conyers, GA 30013</p>
                <p>Phone: (404) 474-3125 | Email: info@omniquestservices.com</p>
            </div>
        </div>
    </body>
    </html>
    """
    
    html_body = render_template_string(html_template, appointment=appointment)
    
    text_body = f"""
    ========================================
    APPOINTMENT CONFIRMATION
    OmniQuest Services
    ========================================
    
    Dear {appointment.user.name},
    
    GREAT NEWS! Your appointment has been successfully confirmed.
    We're looking forward to serving you.
    
    ========================================
    APPOINTMENT DETAILS
    ========================================
    Service: {appointment.service_type.title()}
    Date: {appointment.appointment_date.strftime('%A, %B %d, %Y')}
    Time: {appointment.appointment_time}
    Duration: {appointment.duration_minutes} minutes
    Confirmation ID: #{appointment.id}
    
    Location: 
    {"OmniQuest Services Office, 1540 Highway 138 SE, Suite 4L, Conyers, GA 30013" if appointment.location_type == 'office' else appointment.address}
    
    {f"Amount Paid: ${appointment.payment_amount:.2f}" if appointment.payment_amount else ""}
    
    ========================================
    IMPORTANT REMINDERS
    ========================================
    * Please arrive 10 minutes early to complete any necessary paperwork
    * Bring a valid government-issued photo ID (driver's license, passport, etc.)
    * Cancel or reschedule at least 24 hours in advance if needed
    
    ========================================
    WHAT TO BRING
    ========================================
    * Valid government-issued photo ID
    * Any relevant documents for your service
    * Payment receipt (if not already paid online)
    
    ========================================
    NEED TO MAKE CHANGES?
    ========================================
    Phone: (404) 474-3125
    Email: info@omniquestservices.com
    Business Hours: Monday-Friday 10:00 AM - 6:00 PM, Saturday 10:00 AM - 2:00 PM
    
    We look forward to serving you!
    
    Best regards,
    The OmniQuest Services Team
    
    ========================================
    """
    
    return send_email(
        subject=subject,
        recipients=[appointment.user.email],
        text_body=text_body,
        html_body=html_body
    )

def send_appointment_reminder(appointment):
    """Send appointment reminder email"""
    subject = f"🔔 Appointment Reminder - Tomorrow at {appointment.appointment_time}"
    
    html_template = """
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>Appointment Reminder</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #ff9800, #ff5722); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: white; padding: 30px; border: 1px solid #ddd; }
            .footer { background: #f8f9fa; padding: 20px; text-align: center; border-radius: 0 0 10px 10px; }
            .appointment-details { background: #f8f9fa; padding: 20px; border-radius: 10px; margin: 20px 0; }
            .detail-row { display: flex; justify-content: space-between; margin-bottom: 10px; }
            .important-note { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 20px 0; }
            .contact-info { background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🔔 Appointment Reminder</h1>
                <p>Your appointment is tomorrow!</p>
            </div>
            
            <div class="content">
                <p>Dear {{ appointment.user.name }},</p>
                
                <p><strong>This is a friendly reminder that you have an appointment tomorrow.</strong></p>
                
                <div class="appointment-details">
                    <h3>📅 Tomorrow's Appointment</h3>
                    <div class="detail-row">
                        <strong>Service:</strong>
                        <span>{{ appointment.service_type.title() }}</span>
                    </div>
                    <div class="detail-row">
                        <strong>Date:</strong>
                        <span>{{ appointment.appointment_date.strftime('%A, %B %d, %Y') }}</span>
                    </div>
                    <div class="detail-row">
                        <strong>Time:</strong>
                        <span>{{ appointment.appointment_time }}</span>
                    </div>
                    <div class="detail-row">
                        <strong>Duration:</strong>
                        <span>{{ appointment.duration_minutes }} minutes</span>
                    </div>
                    <div class="detail-row">
                        <strong>Location:</strong>
                        <span>
                            {% if appointment.location_type == 'office' %}
                                🏢 OmniQuest Services Office<br>
                                1540 Highway 138 SE, Suite 4L<br>
                                Conyers, GA 30013
                            {% else %}
                                🚗 {{ appointment.address or 'Mobile Service' }}
                            {% endif %}
                        </span>
                    </div>
                    <div class="detail-row">
                        <strong>Confirmation ID:</strong>
                        <span>#{{ appointment.id }}</span>
                    </div>
                </div>
                
                <div class="important-note">
                    <h3>⚠️ Important Reminders</h3>
                    <ul>
                        <li><strong>Please arrive 10 minutes early</strong> to complete any necessary paperwork</li>
                        <li><strong>Bring a valid government-issued photo ID</strong> (driver's license, passport, etc.)</li>
                        <li><strong>Bring any required documents</strong> for your service</li>
                    </ul>
                </div>
                
                <div class="contact-info">
                    <h3>📞 Need to Make Changes?</h3>
                    <p>If you need to reschedule or have any questions, please contact us immediately:</p>
                    <ul>
                        <li><strong>Phone:</strong> <a href="tel:+14044743125">(404) 474-3125</a></li>
                        <li><strong>Email:</strong> <a href="mailto:info@omniquestservices.com">info@omniquestservices.com</a></li>
                        <li><strong>Business Hours:</strong> Monday-Friday 10:00 AM - 6:00 PM, Saturday 10:00 AM - 2:00 PM</li>
    </ul>
                </div>
                
                <p><strong>We look forward to seeing you tomorrow!</strong></p>
                
                <p>Best regards,<br>The OmniQuest Services Team</p>
            </div>
            
            <div class="footer">
                <p><strong>OmniQuest Services</strong></p>
                <p>1540 Highway 138 SE, Suite 4L, Conyers, GA 30013</p>
                <p>Phone: (404) 474-3125 | Email: info@omniquestservices.com</p>
            </div>
        </div>
    </body>
    </html>
    """
    
    html_body = render_template_string(html_template, appointment=appointment)
    
    text_body = f"""
    ========================================
    APPOINTMENT REMINDER
    OmniQuest Services
    ========================================
    
    Dear {appointment.user.name},
    
    This is a friendly reminder that you have an appointment TOMORROW.
    
    ========================================
    TOMORROW'S APPOINTMENT
    ========================================
    Service: {appointment.service_type.title()}
    Date: {appointment.appointment_date.strftime('%A, %B %d, %Y')}
    Time: {appointment.appointment_time}
    Duration: {appointment.duration_minutes} minutes
    Confirmation ID: #{appointment.id}
    
    Location: 
    {"OmniQuest Services Office, 1540 Highway 138 SE, Suite 4L, Conyers, GA 30013" if appointment.location_type == 'office' else appointment.address}
    
    ========================================
    IMPORTANT REMINDERS
    ========================================
    * Please arrive 10 minutes early to complete any necessary paperwork
    * Bring a valid government-issued photo ID (driver's license, passport, etc.)
    * Bring any required documents for your service
    
    ========================================
    NEED TO MAKE CHANGES?
    ========================================
    Phone: (404) 474-3125
    Email: info@omniquestservices.com
    Business Hours: Monday-Friday 10:00 AM - 6:00 PM, Saturday 10:00 AM - 2:00 PM
    
    We look forward to seeing you tomorrow!
    
    Best regards,
    The OmniQuest Services Team
    
    ========================================
    """
    
    return send_email(
        subject=subject,
        recipients=[appointment.user.email],
        text_body=text_body,
        html_body=html_body
    )

def send_new_lead_notification(lead):
    """Send notification to admin about new lead"""
    subject = f"New {lead.service_type.title()} Lead - {lead.user.name}"
    
    admin_email = current_app.config.get('ADMIN_EMAIL', 'admin@omniquestservices.com')
    
    html_body = f"""
    <h2>New Lead Notification</h2>
    <p>A new lead has been submitted:</p>
    <ul>
        <li><strong>Name:</strong> {lead.user.name}</li>
        <li><strong>Email:</strong> {lead.user.email}</li>
        <li><strong>Phone:</strong> {lead.user.phone or 'Not provided'}</li>
        <li><strong>Service:</strong> {lead.service_type.title()}</li>
        <li><strong>Status:</strong> {lead.status}</li>
        <li><strong>Priority:</strong> {lead.priority}</li>
        <li><strong>Submitted:</strong> {lead.created_at.strftime('%Y-%m-%d %H:%M:%S')}</li>
    </ul>
    <p>Please review and follow up as needed.</p>
    """
    
    return send_email(
        subject=subject,
        recipients=[admin_email],
        html_body=html_body
    )

def send_contact_form_notification(user, message):
    """Send notification about contact form submission"""
    subject = f"New Contact Form Submission - {user.name}"
    
    admin_email = current_app.config.get('ADMIN_EMAIL', 'admin@omniquestservices.com')
    
    html_body = f"""
    <h2>Contact Form Submission</h2>
    <p>A new contact form has been submitted:</p>
    <ul>
        <li><strong>Name:</strong> {user.name}</li>
        <li><strong>Email:</strong> {user.email}</li>
        <li><strong>Phone:</strong> {user.phone or 'Not provided'}</li>
    </ul>
    <p><strong>Message:</strong></p>
    <blockquote>{message}</blockquote>
    <p>Please respond as soon as possible.</p>
    """
    
    return send_email(
        subject=subject,
        recipients=[admin_email],
        html_body=html_body
    )