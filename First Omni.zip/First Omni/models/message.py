from datetime import datetime
from database import db

class Message(db.Model):
    __tablename__ = 'messages'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)  # Can be null for anonymous messages
    sender_type = db.Column(db.String(20), nullable=False)  # user, admin, system, chatbot
    content = db.Column(db.Text, nullable=False)
    message_type = db.Column(db.String(20), nullable=False, default='text')  # text, image, file, system
    is_read = db.Column(db.Boolean, nullable=False, default=False)
    thread_id = db.Column(db.String(50), nullable=True)  # For grouping related messages
    message_metadata = db.Column(db.Text, nullable=True)  # JSON string for additional data
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    read_at = db.Column(db.DateTime, nullable=True)
    
    def __repr__(self):
        return f'<Message {self.id} - {self.sender_type} - {self.created_at}>'
    
    def mark_as_read(self):
        """Mark message as read"""
        self.is_read = True
        self.read_at = datetime.utcnow()
        db.session.commit()
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'sender_type': self.sender_type,
            'content': self.content,
            'message_type': self.message_type,
            'is_read': self.is_read,
            'thread_id': self.thread_id,
            'message_metadata': self.message_metadata,
            'created_at': self.created_at.isoformat(),
            'read_at': self.read_at.isoformat() if self.read_at else None,
            'user': self.user.to_dict() if self.user else None
        }